package com.bbva.smre.dto.cu83old.coordinates;

import java.io.Serializable;
import java.util.List;

public class CU83Location implements Serializable {

	private static final long serialVersionUID = -210556427671529341L;
	
	// Attibutes
	private String document;
	private List<Integer> pages;
	
	// Constructors
	public CU83Location() {
		super();
	}
	
	public CU83Location(String document, List<Integer> pages) {
		super();
		this.document = document;
		this.pages = pages;
	}
	
	// Getters & Setters
	public String getDocument() {
		return document;
	}
	public void setDocument(String document) {
		this.document = document;
	}
	public List<Integer> getPages() {
		return pages;
	}
	public void setPages(List<Integer> pages) {
		this.pages = pages;
	}
	
	// ToString method
	@Override
	public String toString() {
		return "Location [document=" + document + ", pages=" + pages + "]";
	}	
}