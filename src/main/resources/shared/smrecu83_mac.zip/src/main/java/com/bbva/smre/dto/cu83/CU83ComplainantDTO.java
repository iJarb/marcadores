package com.bbva.smre.dto.cu83;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;

public class CU83ComplainantDTO {
    @JsonProperty("internal_intervention_type_desc")
    private String internalInterventionTypeDesc;

    @JsonProperty("personal_type_desc")
    private String personalTypeDesc;

    @JsonProperty("personal_id")
    private String personalId;

    @JsonProperty("loc_pers_id_str")
    private List<CU83LocationDTO> locPersIdStr;

    @JsonProperty("customer_complete_name")
    private String customerCompleteName;

    @JsonProperty("loc_cus_compl_name_str")
    private List<CU83LocationDTO> locCusComplNameStr;

    @JsonProperty("email_desc")
    private String emailDesc;

    @JsonProperty("loc_email_str")
    private List<CU83LocationDTO> locEmailStr;

    // Getters y Setters...
}
