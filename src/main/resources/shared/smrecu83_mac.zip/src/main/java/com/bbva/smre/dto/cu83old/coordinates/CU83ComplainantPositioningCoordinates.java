package com.bbva.smre.dto.cu83old.coordinates;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CU83ComplainantPositioningCoordinates implements Serializable {

	private static final long serialVersionUID = 9187218574172014717L;

	// Attributes
	@JsonProperty("tipo_intervencion")
	private String interventionType;
	
	@JsonProperty("tipo_identificador")
	private String identificationType;
	
	@JsonProperty("numero_identificador")
	private CU83PositioningCoordinates identificationNumber;
	
	@JsonProperty("nombre_razon_social")
	private CU83PositioningCoordinates legalName;
	
	private CU83PositioningCoordinates email;
	
	@JsonProperty("motivo")
	private String reasonIA;

	// Getters & Setters
	public String getInterventionType() {
		return interventionType;
	}

	public void setInterventionType(String interventionType) {
		this.interventionType = interventionType;
	}

	public String getIdentificationType() {
		return identificationType;
	}

	public void setIdentificationType(String identificationType) {
		this.identificationType = identificationType;
	}

	public CU83PositioningCoordinates getIdentificationNumber() {
		return identificationNumber;
	}

	public void setIdentificationNumber(CU83PositioningCoordinates identificationNumber) {
		this.identificationNumber = identificationNumber;
	}

	public CU83PositioningCoordinates getLegalName() {
		return legalName;
	}

	public void setLegalName(CU83PositioningCoordinates legalName) {
		this.legalName = legalName;
	}

	public CU83PositioningCoordinates getEmail() {
		return email;
	}

	public void setEmail(CU83PositioningCoordinates email) {
		this.email = email;
	}

	public String getReasonIA() {
		return reasonIA;
	}

	public void setReasonIA(String reasonIA) {
		this.reasonIA = reasonIA;
	}

	// ToString method
	@Override
	public String toString() {
		return "ComplainantPositioningCoordinates [interventionType=" + interventionType + ", identificationType="
				+ identificationType + ", identificationNumber=" + identificationNumber + ", legalName=" + legalName
				+ ", email=" + email + ", reasonIA=" + reasonIA + "]";
	}
}