package com.bbva.smre.dto.cu83old;

import java.io.Serializable;
import java.util.Objects;


public class CU83TaxonomyDTO implements Serializable  {

    private static final long serialVersionUID = 673863955613135101L;
	private String taxonomyId;
    private String taxonomyDesc;

    public String getTaxonomyId() {
        return taxonomyId;
    }

    public void setTaxonomyId(String taxonomyId) {
        this.taxonomyId = taxonomyId;
    }

    public String getTaxonomyDesc() {
        return taxonomyDesc;
    }

    public void setTaxonomyDesc(String taxonomyDesc) {
        this.taxonomyDesc = taxonomyDesc;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        CU83TaxonomyDTO that = (CU83TaxonomyDTO) o;
        return Objects.equals(taxonomyId, that.taxonomyId) && Objects.equals(taxonomyDesc, that.taxonomyDesc);
    }

    @Override
    public int hashCode() {
        return Objects.hash(taxonomyId, taxonomyDesc);
    }

    @Override
    public String toString() {
        return "CU83TaxonomyDTO{" +
                "taxonomyId='" + taxonomyId + '\'' +
                ", taxonomyDesc='" + taxonomyDesc + '\'' +
                '}';
    }

}
