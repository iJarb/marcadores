package com.bbva.smre.dto.cu83;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CU83IssueDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("total_claim_amount")
    private String totalClaimAmount;

    @JsonProperty("currency_id")
    private String currencyId;

    @JsonProperty("loc_claim_amont_str")
    private List<CU83LocationDTO> locClaimAmountStr;

    @JsonProperty("entry_settlement_date")
    private Date entrySettlementDate;

    @JsonProperty("contract_type_desc")
    private String contractTypeDesc;

    @JsonProperty("con_id_str")
    private List<ConIdStr> conIdStr;

    @JsonProperty("bocf_str")
    private List<BocfStr> bocfStr;

    @JsonProperty("ccc_str")
    private CccStr cccStr;

    @JsonProperty("loc_con_id_str")
    private List<CU83LocationDTO> locConIdStr;

    @JsonProperty("loc_exec_date_str")
    private List<CU83LocationDTO> locExecDateStr;

    @JsonProperty("blind_pan_id")
    private String blindPanId;

    @JsonProperty("loc_pan_ofus_cont_id_str")
    private List<CU83LocationDTO> locPanOfusContIdStr;

    @JsonProperty("taxo_str")
    private List<TaxoStr> taxoStr;

    @JsonProperty("entity_ass_to_claimed_issue_id")
    private String entityAssToClaimedIssueId;

    // Getters y Setters
    public String getTotalClaimAmount() { return totalClaimAmount; }
    public void setTotalClaimAmount(String totalClaimAmount) { this.totalClaimAmount = totalClaimAmount; }
    public String getCurrencyId() { return currencyId; }
    public void setCurrencyId(String currencyId) { this.currencyId = currencyId; }
    public List<CU83LocationDTO> getLocClaimAmountStr() { return locClaimAmountStr; }
    public void setLocClaimAmountStr(List<CU83LocationDTO> locClaimAmountStr) { this.locClaimAmountStr = locClaimAmountStr; }
    public Date getEntrySettlementDate() { return entrySettlementDate; }
    public void setEntrySettlementDate(Date entrySettlementDate) { this.entrySettlementDate = entrySettlementDate; }
    public String getContractTypeDesc() { return contractTypeDesc; }
    public void setContractTypeDesc(String contractTypeDesc) { this.contractTypeDesc = contractTypeDesc; }
    public List<ConIdStr> getConIdStr() { return conIdStr; }
    public void setConIdStr(List<ConIdStr> conIdStr) { this.conIdStr = conIdStr; }
    public List<BocfStr> getBocfStr() { return bocfStr; }
    public void setBocfStr(List<BocfStr> bocfStr) { this.bocfStr = bocfStr; }
    public CccStr getCccStr() { return cccStr; }
    public void setCccStr(CccStr cccStr) { this.cccStr = cccStr; }
    public List<CU83LocationDTO> getLocConIdStr() { return locConIdStr; }
    public void setLocConIdStr(List<CU83LocationDTO> locConIdStr) { this.locConIdStr = locConIdStr; }
    public List<CU83LocationDTO> getLocExecDateStr() { return locExecDateStr; }
    public void setLocExecDateStr(List<CU83LocationDTO> locExecDateStr) { this.locExecDateStr = locExecDateStr; }
    public String getBlindPanId() { return blindPanId; }
    public void setBlindPanId(String blindPanId) { this.blindPanId = blindPanId; }
    public List<CU83LocationDTO> getLocPanOfusContIdStr() { return locPanOfusContIdStr; }
    public void setLocPanOfusContIdStr(List<CU83LocationDTO> locPanOfusContIdStr) { this.locPanOfusContIdStr = locPanOfusContIdStr; }
    public List<TaxoStr> getTaxoStr() { return taxoStr; }
    public void setTaxoStr(List<TaxoStr> taxoStr) { this.taxoStr = taxoStr; }
    public String getEntityAssToClaimedIssueId() { return entityAssToClaimedIssueId; }
    public void setEntityAssToClaimedIssueId(String entityAssToClaimedIssueId) { this.entityAssToClaimedIssueId = entityAssToClaimedIssueId; }
}

// Sub-clases requeridas para CU83IssueDTO según el mapeo JSON
class ConIdStr {
    @JsonProperty("contract_country_id") private String contractCountryId;
    @JsonProperty("contract_entity_id") private String contractEntityId;
    @JsonProperty("contract_id") private String contractId;
    @JsonProperty("dependent_id") private String dependentId;
    @JsonProperty("counterpart_id") private String counterpartId;

    // Getters y Setters...
}

class BocfStr {
    @JsonProperty("entity_page_id") private String entityPageId;
    @JsonProperty("branch_page_id") private String branchPageId;
    @JsonProperty("counterpart_id") private String counterpartId;
    @JsonProperty("page_id") private String pageId;

    // Getters y Setters...
}

class CccStr {
    @JsonProperty("contract_type") private String contractType;
    @JsonProperty("external_contract_id") private String externalContractId;

    // Getters y Setters...
}

class TaxoStr {
    @JsonProperty("complaint_taxonomy_id") private Integer complaintTaxonomyId;
    @JsonProperty("complaint_taxonomy_desc") private String complaintTaxonomyDesc;

    // Getters y Setters...
}
