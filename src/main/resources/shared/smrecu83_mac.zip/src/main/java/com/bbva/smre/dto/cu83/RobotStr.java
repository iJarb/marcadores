package com.bbva.smre.dto.cu83;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RobotStr {

    @JsonProperty("task_priority_type")
    private String taskPriorityType;

    @JsonProperty("respondent_id")
    private String respondentId;

    @JsonProperty("respondent_type")
    private String respondentType;

    @JsonProperty("court_order_resp_docum_number")
    private String courtOrderRespDocumNumber;

    @JsonProperty("cor_proceding_type_id")
    private String corProcedingTypeId;

   }
