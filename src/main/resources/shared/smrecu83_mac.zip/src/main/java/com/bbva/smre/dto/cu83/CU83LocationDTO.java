package com.bbva.smre.dto.cu83;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CU83LocationDTO {
    @JsonProperty("document_desc")
    private String documentDesc;

    @JsonProperty("document_page_number")
    private Short documentPageNumber;

    // Getters y Setters...
}
