package com.bbva.smre.dto.cu83;

import java.util.List;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CourtOrderStr {
    @JsonProperty("authorized_organism_str")
    private List<AuthorizedOrganism> authorizedOrganismStr;

    // Getters y Setters...
}

@Data
@NoArgsConstructor
@AllArgsConstructor
class AuthorizedOrganism {
    @JsonProperty("organism_str")
    private List<OrganismStr> organismStr;

    @JsonProperty("proceeding_number_id")
    private String proceedingNumberId;

    @JsonProperty("cor_proceding_type_id")
    private String corProcedingTypeId;

    @JsonProperty("pu_organism_reference_id")
    private String puOrganismReferenceId;

    @JsonProperty("entry_date")
    private Date entryDate;

    @JsonProperty("respondent_str")
    private List<RespondentStr> respondentStr;

    @JsonProperty("type_court_order_str")
    private List<TypeCourtOrderStr> typeCourtOrderStr;

    @JsonProperty("high_critical_event_str")
    private List<HighCriticalEventStr> highCriticalEventStr;

    @JsonProperty("input_channel_str")
    private List<InputChannelStr> inputChannelStr;

    @JsonProperty("document_str")
    private List<DocumentStr> documentStr;

    @JsonProperty("indicator_str")
    private IndicatorStr indicatorStr;

    @JsonProperty("contracts_str")
    private List<ContractsStr> contractsStr;

    @JsonProperty("seizures_str")
    private SeizuresStr seizuresStr;

    @JsonProperty("notification_date")
    private Date notificationDate;
}

@Data
@NoArgsConstructor
@AllArgsConstructor
class RespondentStr {
    @JsonProperty("identity_document_str")
    private List identityDocumentStr;
    @JsonProperty("full_name") private String fullName;
    @JsonProperty("entity_id") private String entityId;
    @JsonProperty("customer_id") private String customerId;
    @JsonProperty("respondent_id") private String respondentId;
    @JsonProperty("respondent_type") private String respondentType;
}

@Data
@NoArgsConstructor
@AllArgsConstructor
class IdentityDocumentStr {
    @JsonProperty("first_personal_id") private String firstPersonalId;
    @JsonProperty("group_document_type") private String groupDocumentType;
}

@Data
@NoArgsConstructor
@AllArgsConstructor
class TypeCourtOrderStr {
    @JsonProperty("court_order_type_id") private String courtOrderTypeId;
    @JsonProperty("court_order_sub_types_str") private List<CourtOrderSubTypesStr> courtOrderSubTypesStr;
}

@Data
@NoArgsConstructor
@AllArgsConstructor
class CourtOrderSubTypesStr {
    @JsonProperty("court_typology_type") private String courtTypologyType;
    @JsonProperty("court_id") private String courtId;
}

@Data
@NoArgsConstructor
@AllArgsConstructor
class HighCriticalEventStr {
    @JsonProperty("high_criticality_event_type") private String highCriticalityEventType;
}

@Data
@NoArgsConstructor
@AllArgsConstructor
class InputChannelStr {
    @JsonProperty("input_channel_type") private String inputChannelType;
}

@Data
@NoArgsConstructor
@AllArgsConstructor
class DocumentStr {
    @JsonProperty("mail_attachment_id") private String mailAttachmentId;
    @JsonProperty("attachment_type_id") private String attachmentTypeId;
    @JsonProperty("attachment_name") private String attachmentName;
}

@Data
@NoArgsConstructor
@AllArgsConstructor
class IndicatorStr {
    @JsonProperty("entity_employee_type") private String entityEmployeeType;
    @JsonProperty("entity_defendant_type") private String entityDefendantType;
    @JsonProperty("secret_court_order_type") private String secretCourtOrderType;
    @JsonProperty("no_contact_branch_type") private String noContactBranchType;
    @JsonProperty("judicial_notice_type") private String judicialNoticeType;
    @JsonProperty("disobedence_warning_court_type") private String disobedienceWarningCourtType;
    @JsonProperty("judicial_notice_number") private String judicialNoticeNumber;
}

@Data
@NoArgsConstructor
@AllArgsConstructor
class ContractsStr {
    @JsonProperty("contract_required_id") private String contractRequiredId;
}

@Data
@NoArgsConstructor
@AllArgsConstructor
class SeizuresStr {
    @JsonProperty("cor_court_order_amount") private String corCourtOrderAmount;
    @JsonProperty("product_type_str") private List<ProductTypeStr> productTypeStr;
}

@Data
@NoArgsConstructor
@AllArgsConstructor
class ProductTypeStr {
    @JsonProperty("seizure_product_type_id") private String seizureProductTypeId;
}
