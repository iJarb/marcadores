package com.bbva.smre.dto.cu83old;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

public class CU83LocationDTO implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private List<String> documents;
    private List<List<Integer>> pages;

    public List<String> getDocuments() {
        return documents;
    }

    public void setDocuments(List<String> documents) {
        this.documents = documents;
    }

    public List<List<Integer>> getPages() {
        return pages;
    }

    public void setPages(List<List<Integer>> pages) {
        this.pages = pages;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        CU83LocationDTO that = (CU83LocationDTO) o;
        return Objects.equals(documents, that.documents) && Objects.equals(pages, that.pages);
    }

    @Override
    public int hashCode() {
        return Objects.hash(documents, pages);
    }

    @Override
    public String toString() {
        return "LocationDTO{" +
                "documents=" + documents +
                ", pages=" + pages +
                '}';
    }

}
