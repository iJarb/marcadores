package com.bbva.smre.dto.cu83old;

import java.io.Serializable;
import java.util.Objects;

public class CU83IssueDTO  implements Serializable	{

	private static final long serialVersionUID = -7985202535668209030L;
	private CU83PayAmount claimedAmount;
    private CU83LocationDTO claimedAmountLoc;
    private CU83Contract contract;
    private CU83LocationDTO contractLoc;
    private String executionDate;
    private CU83LocationDTO executionDateLoc;
    private String ofuscatedPanId;
    private CU83LocationDTO ofuscatedPanIdLoc;
    private CU83TaxonomyDTO taxonomy;
    
    public CU83PayAmount getClaimedAmount() {
        return claimedAmount;
    }

    public void setClaimedAmount(CU83PayAmount claimedAmount) {
        this.claimedAmount = claimedAmount;
    }

    public CU83LocationDTO getClaimedAmountLoc() {
        return claimedAmountLoc;
    }

    public void setClaimedAmountLoc(CU83LocationDTO claimedAmountLoc) {
        this.claimedAmountLoc = claimedAmountLoc;
    }

    public CU83Contract getContract() {
        return contract;
    }

    public void setContract(CU83Contract contract) {
        this.contract = contract;
    }

    public CU83LocationDTO getContractLoc() {
        return contractLoc;
    }

    public void setContractLoc(CU83LocationDTO contractLoc) {
        this.contractLoc = contractLoc;
    }

    public String getExecutionDate() {
        return executionDate;
    }

    public void setExecutionDate(String executionDate) {
        this.executionDate = executionDate;
    }

    public CU83LocationDTO getExecutionDateLoc() {
        return executionDateLoc;
    }

    public void setExecutionDateLoc(CU83LocationDTO executionDateLoc) {
        this.executionDateLoc = executionDateLoc;
    }

    public String getOfuscatedPanId() {
        return ofuscatedPanId;
    }

    public void setOfuscatedPanId(String ofuscatedPanId) {
        this.ofuscatedPanId = ofuscatedPanId;
    }

    public CU83LocationDTO getOfuscatedPanIdLoc() {
        return ofuscatedPanIdLoc;
    }

    public void setOfuscatedPanIdLoc(CU83LocationDTO ofuscatedPanIdLoc) {
        this.ofuscatedPanIdLoc = ofuscatedPanIdLoc;
    }

    public CU83TaxonomyDTO getTaxonomy() {
        return taxonomy;
    }

    public void setTaxonomy(CU83TaxonomyDTO taxonomy) {
        this.taxonomy = taxonomy;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        CU83IssueDTO issueDTO = (CU83IssueDTO) o;
        return Objects.equals(claimedAmount, issueDTO.claimedAmount) && Objects.equals(claimedAmountLoc, issueDTO.claimedAmountLoc) && Objects.equals(contract, issueDTO.contract) && Objects.equals(contractLoc, issueDTO.contractLoc) && Objects.equals(executionDate, issueDTO.executionDate) && Objects.equals(executionDateLoc, issueDTO.executionDateLoc) && Objects.equals(ofuscatedPanId, issueDTO.ofuscatedPanId) && Objects.equals(ofuscatedPanIdLoc, issueDTO.ofuscatedPanIdLoc) && Objects.equals(taxonomy, issueDTO.taxonomy);
    }

    @Override
    public int hashCode() {
        return Objects.hash(claimedAmount, claimedAmountLoc, contract, contractLoc, executionDate, executionDateLoc, ofuscatedPanId, ofuscatedPanIdLoc, taxonomy);
    }

    @Override
    public String toString() {
        return "IssueDTO{" +
                "claimedAmount=" + claimedAmount +
                ", claimedAmountLoc=" + claimedAmountLoc +
                ", contract=" + contract +
                ", contractLoc=" + contractLoc +
                ", executionDate='" + executionDate + '\'' +
                ", executionDateLoc=" + executionDateLoc +
                ", ofuscatedPanId='" + ofuscatedPanId + '\'' +
                ", ofuscatedPanIdLoc=" + ofuscatedPanIdLoc +
                ", taxonomy=" + taxonomy +
                '}';
    }
}
