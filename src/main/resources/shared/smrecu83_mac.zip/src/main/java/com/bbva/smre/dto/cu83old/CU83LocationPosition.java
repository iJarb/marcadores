package com.bbva.smre.dto.cu83old;

import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;



public class CU83LocationPosition implements Serializable  {
	private static final long serialVersionUID = 2931699728946643245L;
    private List<CU83DocumentPosition> documents;
    private List<CU83PagesPosition> pages;

    public List<CU83DocumentPosition> getDocuments() {
        return documents;
    }

    public void setDocuments(List<CU83DocumentPosition> documents) {
        this.documents = documents;
    }

    public List<CU83PagesPosition> getPages() {
        return pages;
    }

    public void setPages(List<CU83PagesPosition> pages) {
        this.pages = pages;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        CU83LocationPosition that = (CU83LocationPosition) o;
        return Objects.equals(documents, that.documents) && Objects.equals(pages, that.pages);
    }

    @Override
    public int hashCode() {
        return Objects.hash(documents, pages);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("documentsPosition", documents)
                .append("pagesPositionList", pages)
                .toString();
    }
}