package com.bbva.smre.dto.cu83old;

import java.io.Serializable;
import java.util.Objects;



public class CU83ComplainantDTO implements Serializable  {
	private static final long serialVersionUID = 2931699728946643245L;

    private CU83IdentifierEntity interventionType;
    private CU83IdentifierEntity indentificationType;
    private CU83LocationDTO identificationTypeLoc;
    private String customerCompleteName;
    private CU83LocationDTO customerCompleteNameLoc;
    private String email;
    private CU83LocationDTO emailLoc;

    public CU83IdentifierEntity getInterventionType() {
        return interventionType;
    }

    public void setInterventionType(CU83IdentifierEntity interventionType) {
        this.interventionType = interventionType;
    }

    public CU83IdentifierEntity getIndentificationType() {
        return indentificationType;
    }

    public void setIndentificationType(CU83IdentifierEntity indentificationType) {
        this.indentificationType = indentificationType;
    }

    public CU83LocationDTO getIdentificationTypeLoc() {
        return identificationTypeLoc;
    }

    public void setIdentificationTypeLoc(CU83LocationDTO identificationTypeLoc) {
        this.identificationTypeLoc = identificationTypeLoc;
    }

    public String getCustomerCompleteName() {
        return customerCompleteName;
    }

    public void setCustomerCompleteName(String customerCompleteName) {
        this.customerCompleteName = customerCompleteName;
    }

    public CU83LocationDTO getCustomerCompleteNameLoc() {
        return customerCompleteNameLoc;
    }

    public void setCustomerCompleteNameLoc(CU83LocationDTO customerCompleteNameLoc) {
        this.customerCompleteNameLoc = customerCompleteNameLoc;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public CU83LocationDTO getEmailLoc() {
        return emailLoc;
    }

    public void setEmailLoc(CU83LocationDTO emailLoc) {
        this.emailLoc = emailLoc;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        CU83ComplainantDTO that = (CU83ComplainantDTO) o;
        return Objects.equals(interventionType, that.interventionType) && Objects.equals(indentificationType, that.indentificationType) && Objects.equals(identificationTypeLoc, that.identificationTypeLoc) && Objects.equals(customerCompleteName, that.customerCompleteName) && Objects.equals(customerCompleteNameLoc, that.customerCompleteNameLoc) && Objects.equals(email, that.email) && Objects.equals(emailLoc, that.emailLoc);
    }

    @Override
    public int hashCode() {
        return Objects.hash(interventionType, indentificationType, identificationTypeLoc, customerCompleteName, customerCompleteNameLoc, email, emailLoc);
    }

    @Override
    public String toString() {
        return "ComplainantDTO{" +
                "interventionType=" + interventionType +
                ", indentificationType=" + indentificationType +
                ", identificationTypeLoc=" + identificationTypeLoc +
                ", customerCompleteName='" + customerCompleteName + '\'' +
                ", customerCompleteNameLoc=" + customerCompleteNameLoc +
                ", email='" + email + '\'' +
                ", emailLoc=" + emailLoc +
                '}';
    }
}