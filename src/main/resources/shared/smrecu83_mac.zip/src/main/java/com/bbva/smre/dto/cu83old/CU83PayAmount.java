package com.bbva.smre.dto.cu83old;

import java.io.Serializable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;


public class CU83PayAmount implements Serializable {
	private static final long serialVersionUID = 2931699728946643245L;

	private Double amount;
	private String currency;
	private CU83LocationPosition location;

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public CU83LocationPosition getLocation() {
		return location;
	}

	public void setLocation(CU83LocationPosition location) {
		this.location = location;
	}

	/**
	 * Indicates whether some other object is "equal to" this one.
	 */
	@Override
	public boolean equals(final Object obj) {
		if (obj == null) { return false; }
		if (obj == this) { return true; }
		if (obj.getClass() != getClass()) {
			return false;
		}
		final CU83PayAmount rhs = (CU83PayAmount) obj;
		return new EqualsBuilder().appendSuper(super.equals(obj))
					.append(amount, rhs.amount)
					.append(currency, rhs.currency)
					.append(location, rhs.location)
					.isEquals();
	}

	/**
	 * Returns a hash code value for the object.
	 */
	@Override
	public int hashCode() {
		return new HashCodeBuilder()
			.append(this.amount)
			.append(this.currency).append(this.location)
			.toHashCode();
	}

	/**
	 * Returns a string representation of the object.
	 * It is important to OBFUSCATE the attributes that are sensitive to show in the representation.
	 */
	@Override
	public String toString() {
		return new ToStringBuilder(this)
			.append("amount", amount)
			.append("currency", currency).append("location", location)
			.toString();
	}
}