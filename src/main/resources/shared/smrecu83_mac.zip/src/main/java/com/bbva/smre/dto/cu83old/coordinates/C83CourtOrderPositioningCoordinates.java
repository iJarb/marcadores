package com.bbva.smre.dto.cu83old.coordinates;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;



@JsonIgnoreProperties(ignoreUnknown = true)
public class C83CourtOrderPositioningCoordinates implements Serializable {

	private static final long serialVersionUID = 4196936565048898284L;

	// Attributes
	@JsonProperty("id")
	private String idMail;
	
	@JsonProperty("intervinientes")
	private List<CU83ComplainantPositioningCoordinates> complainants;
	
	@JsonProperty("codigo_referencia_externa")
	private CU83PositioningCoordinates representativeOrganization;
	
	@JsonProperty("codigo_oficio_motivo")
	private CU83PositioningCoordinates reasonId;
	
	@JsonProperty("codigo_oficio_id")
	private CU83PositioningCoordinates linkedCourtOrderId;
	
	@JsonProperty("asuntos")
	private List<CU83IssuePositioningCoordinates> issues;

	// Getters & Setters
	public String getIdMail() {
		return idMail;
	}

	public void setIdMail(String idMail) {
		this.idMail = idMail;
	}

	public List<CU83ComplainantPositioningCoordinates> getComplainants() {
		return complainants;
	}

	public void setComplainants(List<CU83ComplainantPositioningCoordinates> complainants) {
		this.complainants = complainants;
	}

	public CU83PositioningCoordinates getRepresentativeOrganization() {
		return representativeOrganization;
	}

	public void setRepresentativeOrganization(CU83PositioningCoordinates representativeOrganization) {
		this.representativeOrganization = representativeOrganization;
	}

	public CU83PositioningCoordinates getReasonId() {
		return reasonId;
	}

	public void setReasonId(CU83PositioningCoordinates reasonId) {
		this.reasonId = reasonId;
	}

	public CU83PositioningCoordinates getLinkedComplaintId() {
		return linkedCourtOrderId;
	}

	public void setLinkedComplaintId(CU83PositioningCoordinates linkedComplaintId) {
		this.linkedCourtOrderId = linkedComplaintId;
	}

	public List<CU83IssuePositioningCoordinates> getIssues() {
		return issues;
	}

	public void setIssues(List<CU83IssuePositioningCoordinates> issues) {
		this.issues = issues;
	}

	// ToString method
	@Override
	public String toString() {
		return "C83CourtOrderPositioningCoordinates [idMail=" + idMail + ", complainants=" + complainants
				+ ", representativeOrganization=" + representativeOrganization + ", reasonId=" + reasonId
				+ ", linkedCourtOrderId=" + linkedCourtOrderId + ", issues=" + issues + "]";
	}
}