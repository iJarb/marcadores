package com.bbva.smre.dto.cu83old;



import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

public class CU83PagesPosition implements Serializable {
    private static final long serialVersionUID = 2931699728946643245L;
    private List<CU83PagePosition> page;

    public List<CU83PagePosition> getPage() {
        return page;
    }

    public void setPage(List<CU83PagePosition> page) {
        this.page = page;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        CU83PagesPosition that = (CU83PagesPosition) o;
        return Objects.equals(page, that.page);
    }

    @Override
    public int hashCode() {
        return Objects.hash(page);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("pages", page)
                .toString();
    }
}