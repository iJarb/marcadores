package com.bbva.smre.dto.cu83old;

import java.io.Serializable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;


public class CU83ContractFormat implements Serializable {
	private static final long serialVersionUID = 2931699728946643245L;

	private String iuc;
	private String insurance;
	private String bocf;
	private String ccc;
	private String iban;
	private Long comexOperationCode;

	public String getIuc() {
		return iuc;
	}

	public void setIuc(String iuc) {
		this.iuc = iuc;
	}

	public String getInsurance() {
		return insurance;
	}

	public void setInsurance(String insurance) {
		this.insurance = insurance;
	}

	public String getBocf() {
		return bocf;
	}

	public void setBocf(String bocf) {
		this.bocf = bocf;
	}

	public String getCcc() {
		return ccc;
	}

	public void setCcc(String ccc) {
		this.ccc = ccc;
	}

	public String getIban() {
		return iban;
	}

	public void setIban(String iban) {
		this.iban = iban;
	}

	public Long getComexOperationCode() {
		return comexOperationCode;
	}

	public void setComexOperationCode(Long comexOperationCode) {
		this.comexOperationCode = comexOperationCode;
	}

	/**
	 * Indicates whether some other object is "equal to" this one.
	 */
	@Override
	public boolean equals(final Object obj) {
		if (obj == null) { return false; }
		if (obj == this) { return true; }
		if (obj.getClass() != getClass()) {
			return false;
		}
		final CU83ContractFormat rhs = (CU83ContractFormat) obj;
		return new EqualsBuilder().appendSuper(super.equals(obj))
					.append(iuc, rhs.iuc)
					.append(insurance, rhs.insurance)
					.append(bocf, rhs.bocf)
					.append(ccc, rhs.ccc)
					.append(iban, rhs.iban)
					.append(comexOperationCode, rhs.comexOperationCode)
					.isEquals();
	}

	/**
	 * Returns a hash code value for the object.
	 */
	@Override
	public int hashCode() {
		return new HashCodeBuilder()
			.append(this.iuc)
			.append(this.insurance)
			.append(this.bocf)
			.append(this.ccc)
			.append(this.iban)
			.append(this.comexOperationCode)
			.toHashCode();
	}

	/**
	 * Returns a string representation of the object.
	 * It is important to OBFUSCATE the attributes that are sensitive to show in the representation.
	 */
	@Override
	public String toString() {
		return new ToStringBuilder(this)
			.append("iuc", iuc)
			.append("insurance", insurance)
			.append("bocf", bocf)
			.append("ccc", ccc)
			.append("iban", iban)
			.append("comexOperationCode", comexOperationCode)
			.toString();
	}
}