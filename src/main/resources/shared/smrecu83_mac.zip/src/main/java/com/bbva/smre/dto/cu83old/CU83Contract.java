package com.bbva.smre.dto.cu83old;

import java.io.Serializable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;


public class CU83Contract implements Serializable {
	private static final long serialVersionUID = 2931699728946643245L;

	private String type;
	private String bank;
	private String branch;
	private String productId;
	private String counterpart;
	private String countryCode;
	private String certificate;
	private CU83ContractFormat format;
	private CU83LocationPosition contractLocation;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getBank() {
		return bank;
	}

	public void setBank(String bank) {
		this.bank = bank;
	}
	
	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getCounterpart() {
		return counterpart;
	}

	public void setCounterpart(String counterpart) {
		this.counterpart = counterpart;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getCertificate() {
		return certificate;
	}

	public void setCertificate(String certificate) {
		this.certificate = certificate;
	}

	public CU83ContractFormat getFormat() {
		return format;
	}

	public void setFormat(CU83ContractFormat format) {
		this.format = format;
	}
	public CU83LocationPosition getContractLocation() {
		return contractLocation;
	}

	public void setContractLocation(CU83LocationPosition contractLocation) {
		this.contractLocation = contractLocation;
	}

	/**
	 * Indicates whether some other object is "equal to" this one.
	 */
	@Override
	public boolean equals(final Object obj) {
		if (obj == null) { return false; }
		if (obj == this) { return true; }
		if (obj.getClass() != getClass()) {
			return false;
		}
		final CU83Contract rhs = (CU83Contract) obj;
		return new EqualsBuilder().appendSuper(super.equals(obj))
					.append(type, rhs.type)
					.append(bank, rhs.bank)
					.append(branch, rhs.branch)
					.append(productId, rhs.productId)
					.append(counterpart, rhs.counterpart)
					.append(countryCode, rhs.countryCode)
					.append(certificate, rhs.certificate)
					.append(format, rhs.format)
					.append(contractLocation, rhs.contractLocation)
					.isEquals();
	}

	/**
	 * Returns a hash code value for the object.
	 */
	@Override
	public int hashCode() {
		return new HashCodeBuilder()
			.append(this.type)
			.append(this.bank)
			.append(this.branch)
			.append(this.productId)
			.append(this.counterpart)
			.append(this.countryCode)
			.append(this.certificate)
			.append(this.format).append(this.contractLocation)
			.toHashCode();
	}

	/**
	 * Returns a string representation of the object.
	 * It is important to OBFUSCATE the attributes that are sensitive to show in the representation.
	 */
	@Override
	public String toString() {
		return new ToStringBuilder(this)
			.append("type", type)
			.append("bank", bank)
			.append("branch", branch)
			.append("productId", productId)
			.append("counterpart", counterpart)
			.append("countryCode", countryCode)
			.append("certificate", certificate)
			.append("format", format).append("location", contractLocation)
			.toString();
	}
}