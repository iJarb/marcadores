package com.bbva.smre.dto.cu83;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OrganismStr {

    @JsonProperty("pu_organism_id")
    private String puOrganismId;

    @JsonProperty("organism_type")
    private String organismType;

    @JsonProperty("pu_organism_subtype_id")
    private String puOrganismSubtypeId;

    @JsonProperty("pu_external_public_organism_id")
    private String puExternalPublicOrganismId;

    @JsonProperty("pu_organism_scope_id")
    private String puOrganismScopeId;

   
}
