package com.bbva.smre.dto.cu83old.coordinates;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CU83PositioningCoordinates implements Serializable {

	private static final long serialVersionUID = 8101188204613407182L;

	// Attributes
	@JsonProperty("valor")
	private String value;
	
	private List<CU83Location> location;
	
	@JsonProperty("motivo")
	private String reasonIA;

	// Getters & Setters
	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public List<CU83Location> getLocation() {
		return location;
	}

	public void setLocation(List<CU83Location> location) {
		this.location = location;
	}

	public String getReasonIA() {
		return reasonIA;
	}

	public void setReasonIA(String reasonIA) {
		this.reasonIA = reasonIA;
	}

	// ToString method
	@Override
	public String toString() {
		return "PositioningCoordinates [value=" + value + ", location=" + location + ", reasonIA=" + reasonIA + "]";
	}
}