package com.bbva.smre.dto.cu83;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EventStr {

    @JsonProperty("email_reception_date")
    private Date emailReceptionDate;

    @JsonProperty("claimed_issue_email_desc")
    private String claimedIssueEmailDesc;

    @JsonProperty("sender_email_desc")
    private String senderEmailDesc;

    @JsonProperty("destination_email_desc")
    private String destinationEmailDesc;

  
}
