package com.bbva.smre.dto.cu83old.coordinates;

import java.io.Serializable;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CU83IssuePositioningCoordinates implements Serializable {

	private static final long serialVersionUID = 5242794736089385457L;

	// Attributes
	@JsonProperty("importe_reclamado")
	private CU83PositioningCoordinates claimedAmount;
	
	@JsonProperty("divisa_contrato")
	private CU83PositioningCoordinates currency;
	
	@JsonProperty("tipo_identificador_contrato")
	private CU83PositioningCoordinates contractIdentifierType;
	
	@JsonProperty("numero_identificador_contrato")
	private CU83PositioningCoordinates contractIdentifierNumber;
	
	@JsonProperty("fecha_formalizacion")
	private CU83PositioningCoordinates formalizationDate;
	
	private Map<String, String> taxonomy;
	
	@JsonProperty("numero_identificador_contrato_pan_ofusca")
	private CU83PositioningCoordinates obfuscatedPan;

	// Getters & Setters
	public CU83PositioningCoordinates getClaimedAmount() {
		return claimedAmount;
	}

	public void setClaimedAmount(CU83PositioningCoordinates claimedAmount) {
		this.claimedAmount = claimedAmount;
	}

	public CU83PositioningCoordinates getCurrency() {
		return currency;
	}

	public void setCurrency(CU83PositioningCoordinates currency) {
		this.currency = currency;
	}

	public CU83PositioningCoordinates getContractIdentifierType() {
		return contractIdentifierType;
	}

	public void setContractIdentifierType(CU83PositioningCoordinates contractIdentifierType) {
		this.contractIdentifierType = contractIdentifierType;
	}

	public CU83PositioningCoordinates getContractIdentifierNumber() {
		return contractIdentifierNumber;
	}

	public void setContractIdentifierNumber(CU83PositioningCoordinates contractIdentifierNumber) {
		this.contractIdentifierNumber = contractIdentifierNumber;
	}

	public CU83PositioningCoordinates getFormalizationDate() {
		return formalizationDate;
	}

	public void setFormalizationDate(CU83PositioningCoordinates formalizationDate) {
		this.formalizationDate = formalizationDate;
	}

	public Map<String, String> getTaxonomy() {
		return taxonomy;
	}

	public void setTaxonomy(Map<String, String> taxonomy) {
		this.taxonomy = taxonomy;
	}

	public CU83PositioningCoordinates getObfuscatedPan() {
		return obfuscatedPan;
	}

	public void setObfuscatedPan(CU83PositioningCoordinates obfuscatedPan) {
		this.obfuscatedPan = obfuscatedPan;
	}

	// ToString method
	@Override
	public String toString() {
		return "IssuePositioningCoordinates [claimedAmount=" + claimedAmount + ", currency=" + currency
				+ ", contractIdentifierType=" + contractIdentifierType + ", contractIdentifierNumber="
				+ contractIdentifierNumber + ", formalizationDate=" + formalizationDate + ", taxonomy=" + taxonomy
				+ ", obfuscatedPan=" + obfuscatedPan + "]";
	}
}