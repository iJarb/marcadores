package com.bbva.smre.dto.cu83old;

import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;
import java.util.Objects;

public class CU83DocumentPosition implements Serializable {
    private static final long serialVersionUID = 2931699728946643245L;
    private String document;

    public String getDocument() {
        return document;
    }

    public void setDocument(String document) {
        this.document = document;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        CU83DocumentPosition that = (CU83DocumentPosition) o;
        return Objects.equals(document, that.document);
    }

    @Override
    public int hashCode() {
        return Objects.hash(document);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("document", document)
                .toString();
    }
}