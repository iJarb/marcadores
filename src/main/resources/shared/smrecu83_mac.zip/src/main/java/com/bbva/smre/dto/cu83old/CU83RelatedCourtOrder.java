package com.bbva.smre.dto.cu83old;

import java.io.Serializable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;


public class CU83RelatedCourtOrder implements Serializable  {

	
	private static final long serialVersionUID = 1L;
	
	private Long courtOrderId;
	private String roleType;
	private String relationDate;
	private CU83LocationDTO relatedCourtOrderLocation;
	
	
	


	public Long getCourtOrderId() {
		return courtOrderId;
	}


	public void setCourtOrderId(Long courtOrderId) {
		this.courtOrderId = courtOrderId;
	}


	public String getRoleType() {
		return roleType;
	}


	public void setRoleType(String roleType) {
		this.roleType = roleType;
	}


	public String getRelationDate() {
		return relationDate;
	}


	public void setRelationDate(String relationDate) {
		this.relationDate = relationDate;
	}


	public CU83LocationDTO getRelatedCourtOrderLocation() {
		return relatedCourtOrderLocation;
	}


	public void setRelatedCourtOrderLocation(CU83LocationDTO relatedCourtOrderLocation) {
		this.relatedCourtOrderLocation = relatedCourtOrderLocation;
	}
	
	@Override
	public boolean equals(final Object obj) {
		if (obj == null) { return false; }
		if (obj == this) { return true; }
		if (obj.getClass() != getClass()) {
			return false;
		}
		final CU83RelatedCourtOrder rhs = (CU83RelatedCourtOrder) obj;
		return new EqualsBuilder().appendSuper(super.equals(obj))
					.append(courtOrderId, rhs.courtOrderId)
					.append(roleType, rhs.roleType)
					.append(relationDate, rhs.relationDate)
					.append(relatedCourtOrderLocation, rhs.relatedCourtOrderLocation)
					.isEquals();
	}

	
	@Override
	public int hashCode() {
		return new HashCodeBuilder()
			.append(this.courtOrderId)
			.append(this.roleType)
			.append(this.relationDate).append(relatedCourtOrderLocation)
			.toHashCode();
	}

	
	@Override
	public String toString() {
		return new ToStringBuilder(this)
			.append("complaintId", courtOrderId)
			.append("roleType", roleType)
			.append("relationDate", relationDate).append("location", relatedCourtOrderLocation)
			.toString();
	}
}
