package com.bbva.smre.dto.cu83old;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;


public class CU83CourtOrderDTO implements Serializable  {
	
	
	private static final long serialVersionUID = 2931699728946643245L;

    
    private List<CU83ComplainantDTO> complainants;
    
    private CU83LocationDTO publicOrganismReferenceLoc;
    private String reasonCodeId;
    private CU83RelatedCourtOrder relatedCourtOrder;
    private CU83LocationDTO courtOrderIdLoc;
    private List<CU83IssueDTO> issues;
	

	private String id;

	private String publicOrganismReference;

	public String getId() {
		return this.id;
	}

	public void setId(final String id) {
		this.id = id;
	}

	public String getPublicOrganismReference() {
		return this.publicOrganismReference;
	}

	public void setPublicOrganismReference(final String publicOrganismReference) {
		this.publicOrganismReference = publicOrganismReference;
	}

	

	public List<CU83ComplainantDTO> getComplainants() {
		return complainants;
	}

	public void setComplainants(List<CU83ComplainantDTO> complainants) {
		this.complainants = complainants;
	}

	public CU83LocationDTO getPublicOrganismReferenceLoc() {
		return publicOrganismReferenceLoc;
	}

	public void setPublicOrganismReferenceLoc(CU83LocationDTO publicOrganismReferenceLoc) {
		this.publicOrganismReferenceLoc = publicOrganismReferenceLoc;
	}

	public String getReasonCodeId() {
		return reasonCodeId;
	}

	public void setReasonCodeId(String reasonCodeId) {
		this.reasonCodeId = reasonCodeId;
	}

	public CU83RelatedCourtOrder getRelatedCourtOrder() {
		return relatedCourtOrder;
	}

	public void setRelatedCourtOrder(CU83RelatedCourtOrder relatedCourtOrder) {
		this.relatedCourtOrder = relatedCourtOrder;
	}

	public CU83LocationDTO getCourtOrderIdLoc() {
		return courtOrderIdLoc;
	}

	public void setCourtOrderIdLoc(CU83LocationDTO courtOrderIdLoc) {
		this.courtOrderIdLoc = courtOrderIdLoc;
	}

	public List<CU83IssueDTO> getIssues() {
		return issues;
	}

	public void setIssues(List<CU83IssueDTO> issues) {
		this.issues = issues;
	}
	
	@Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        CU83CourtOrderDTO that = (CU83CourtOrderDTO) o;
        return Objects.equals(id, that.id) && Objects.equals(complainants, that.complainants) && Objects.equals(publicOrganismReference, that.publicOrganismReference) && Objects.equals(publicOrganismReferenceLoc, that.publicOrganismReferenceLoc) && Objects.equals(reasonCodeId, that.reasonCodeId) && Objects.equals(relatedCourtOrder, that.relatedCourtOrder) && Objects.equals(courtOrderIdLoc, that.courtOrderIdLoc) && Objects.equals(issues, that.issues);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, complainants, publicOrganismReference, publicOrganismReferenceLoc, reasonCodeId, relatedCourtOrder, courtOrderIdLoc, issues);
    }

    @Override
    public String toString() {
        return "ComplaintDTO{" +
                "id='" + id + '\'' +
                ", complainants=" + complainants +
                ", publicOrganismReference='" + publicOrganismReference + '\'' +
                ", publicOrganismReferenceLoc=" + publicOrganismReferenceLoc +
                ", reasonCodeId='" + reasonCodeId + '\'' +
                ", relatedCourtOrder=" + relatedCourtOrder +
                ", complaintIdLoc=" + courtOrderIdLoc +
                ", issues=" + issues +
                '}';
    }
}
