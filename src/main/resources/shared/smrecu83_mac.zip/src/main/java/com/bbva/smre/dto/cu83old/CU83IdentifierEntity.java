package com.bbva.smre.dto.cu83old;

import java.io.Serializable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * The IdentifierEntity class...
 */
public class CU83IdentifierEntity implements Serializable {
	private static final long serialVersionUID = 2931699728946643245L;


	private String id;
	private String name;
	private CU83LocationPosition location;
	
	public CU83IdentifierEntity() {
		super();
	}

	public CU83IdentifierEntity(String id) {
		super();
		this.id = id;
	}

	public CU83IdentifierEntity(String id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public CU83IdentifierEntity(String id, String name, CU83LocationPosition location) {
		super();
		this.id = id;
		this.name = name;
		this.location = location;
	}

	/**
	 * Get the id attribute
	 */
	public String getId() {
		return this.id;
	}

	/**
	 * Set the id attribute
	 */
	public void setId(final String id) {
		this.id = id;
	}

	/**
	 * Get the name attribute
	 */
	public String getName() {
		return this.name;
	}

	/**
	 * Set the name attribute
	 */
	public void setName(final String name) {
		this.name = name;
	}

	/**
	 * Get the location attribute
	 */
	public CU83LocationPosition getLocation() {
		return this.location;
	}

	/**
	 * Set the location attribute
	 */
	public void setLocation(final CU83LocationPosition location) {
		this.location = location;
	}

	/**
	 * Indicates whether some other object is "equal to" this one.
	 */
	@Override
	public boolean equals(final Object obj) {
		if (obj == null) { return false; }
		if (obj == this) { return true; }
		if (obj.getClass() != getClass()) {
			return false;
		}
		final CU83IdentifierEntity rhs = (CU83IdentifierEntity) obj;
		return new EqualsBuilder().appendSuper(super.equals(obj))
					.append(id, rhs.id)
					.append(name, rhs.name)
					.append(location, rhs.location)
					.isEquals();
	}

	/**
	 * Returns a hash code value for the object.
	 */
	@Override
	public int hashCode() {
		return new HashCodeBuilder()
			.append(this.id)
			.append(this.name).append(this.location)
			.toHashCode();
	}

	/**
	 * Returns a string representation of the object.
	 * It is important to OBFUSCATE the attributes that are sensitive to show in the representation.
	 */
	@Override
	public String toString() {
		return new ToStringBuilder(this)
			.append("id", id)
			.append("name", name).append("location", location)
			.toString();
	}
}