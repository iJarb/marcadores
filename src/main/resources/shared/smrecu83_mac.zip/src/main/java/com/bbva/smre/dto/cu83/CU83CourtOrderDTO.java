package com.bbva.smre.dto.cu83;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL) // Evita enviar nulos que rompan el modo 'strict'
public class CU83CourtOrderDTO implements Serializable {

    private static final long serialVersionUID = 2931699728946643245L;

    @JsonProperty("id")
    private String id;

    @JsonProperty("mailbox_desc")
    private String mailboxDesc;

    @JsonProperty("mail_uniq_id")
    private String mailUniqId;

    @JsonProperty("judicial_file_id")
    private String judicialFileId;

    @JsonProperty("court_order_id")
    private Short courtOrderId;

    @JsonProperty("miof_court_order_id")
    private String miofCourtOrderId;

    @JsonProperty("related_judicial_file_id")
    private String relatedJudicialFileId;

    @JsonProperty("tk_task_id")
    private String tkTaskId;

    @JsonProperty("court_order_type_id")
    private String courtOrderTypeId;

    @JsonProperty("court_order_sub_type")
    private String courtOrderSubType;

    @JsonProperty("taxonomy_reason_id")
    private String taxonomyReasonId;

    @JsonProperty("complaint_register_status_type")
    private String complaintRegisterStatusType;

    @JsonProperty("organism_str")
    private List<OrganismStr> organismStr;

    @JsonProperty("comp_str")
    private List<CU83ComplainantDTO> compStr; 

    @JsonProperty("loc_pu_org_ref_id_str")
    private List<CU83LocationDTO> locPuOrgRefIdStr; 

    @JsonProperty("loc_comp_id_str")
    private List<CU83LocationDTO> locCompIdStr;

    @JsonProperty("isses_str")
    private List<CU83IssueDTO> issesStr; 

    @JsonProperty("event_str")
    private List<EventStr> eventStr;

    @JsonProperty("robot_str")
    private List<RobotStr> robotStr;

    @JsonProperty("court_order_str")
    private CourtOrderStr courtOrderStr;

    @JsonProperty("audit_user_id")
    private String auditUserId;

    @JsonProperty("audit_date")
    private Date auditDate;

   
}
