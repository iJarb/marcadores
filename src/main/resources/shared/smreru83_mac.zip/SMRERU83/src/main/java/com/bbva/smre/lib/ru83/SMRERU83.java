package com.bbva.smre.lib.ru83;

import java.util.List;

import com.bbva.smre.dto.cu83.CU83CourtOrderDTO;


public interface SMRERU83 {
	
	List<com.bbva.smre.dto.cu83.CU83CourtOrderDTO> executeGetCourtOrder(String id);
	void executeInsertCourtOrderCoordinates(CU83CourtOrderDTO courtOrderCoordinates);

}
