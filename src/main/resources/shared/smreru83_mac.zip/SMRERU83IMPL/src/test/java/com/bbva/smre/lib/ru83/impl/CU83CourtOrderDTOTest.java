package com.bbva.smre.lib.ru83.impl;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Collections;
import java.util.Date;
import java.util.Calendar;
import java.util.TimeZone;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


import com.bbva.smre.dto.cu83.CU83CourtOrderDTO;
import com.bbva.smre.dto.cu83.RobotStr;
import com.bbva.smre.lib.ru83.mappers.ElasticObjectMapperFactory;
import com.fasterxml.jackson.databind.ObjectMapper;

public class CU83CourtOrderDTOTest {
	
	private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        // Inicializamos el ObjectMapper utilizando la factoría corregida
        this.objectMapper = ElasticObjectMapperFactory.createObjectMapper();
    }

    @Test
    void debeSerializarAJsonValidoParaElasticsearchEstricto() throws Exception {
        // 1. ARRANGEMENT: Crear un DTO Dummy con datos representativos de tu mapeo
        CU83CourtOrderDTO courtOrderDTO = new CU83CourtOrderDTO();
        courtOrderDTO.setMailboxDesc("Mailbox Principal");
        courtOrderDTO.setCourtOrderId((short) 123);
        
        // Configuramos una fecha fija para evitar discrepancias por la zona horaria en el test
        Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        calendar.set(2026, Calendar.OCTOBER, 7, 10, 0, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        Date fechaTest = calendar.getTime();
        courtOrderDTO.setAuditDate(fechaTest);

        // Agregamos un elemento en un campo anidado (nested) como 'robot_str'
        RobotStr robot = new RobotStr();
        robot.setTaskPriorityType("HIGH");
        robot.setRespondentId("RESP-001");
        courtOrderDTO.setRobotStr(Collections.singletonList(robot));

        // Dejamos intencionalmente otros campos en 'null' (ej. mailUniqId, compStr) 
        // para verificar que la exclusión funcione correctamente.

        // 2. ACTION: Convertir el DTO a String JSON
        String jsonResult = objectMapper.writeValueAsString(courtOrderDTO);

        // Imprime el JSON en la consola de JUnit para inspección visual rápida
        System.out.println("JSON Generado: " + jsonResult);

        // 3. ASSERTIONS: Validaciones del formato estricto
        
        // Validar que se respete el formato snake_case en propiedades de la raíz
        assertThat(jsonResult).contains("\"mailbox_desc\":\"Mailbox Principal\"");
        assertThat(jsonResult).contains("\"court_order_id\":123");
        
        // Validar que se respete el formato snake_case dentro del objeto anidado (nested)
        assertThat(jsonResult).contains("\"robot_str\":[");
        assertThat(jsonResult).contains("\"task_priority_type\":\"HIGH\"");
        assertThat(jsonResult).contains("\"respondent_id\":\"RESP-001\"");

        // Validar la regla crítica: Los valores nulos NO deben aparecer en el JSON
        assertThat(jsonResult).doesNotContain("mail_uniq_id");
        assertThat(jsonResult).doesNotContain("comp_str");

        // Validar el formato de fecha ISO-8601 requerido por Elasticsearch ("type": "date")
        // No debe contener el timestamp numérico tipo: 1791367200000
        assertThat(jsonResult).doesNotContain("\"audit_date\":17"); 
        // Debe contener la cadena de texto formateada en UTC
        assertThat(jsonResult).contains("\"audit_date\":\"2026-10-07T10:00:00.000+00:00\"");
    }
    
    @Test
    void debeDeserializarIgnorandoMetadatosDesconocidosDeElasticsearch() throws Exception {
        // Simula un JSON devuelto por una consulta a Elasticsearch que incluye metadatos como '_id' o '_score'
        String jsonDesdeElastic = "{"
                + "\"mailbox_desc\":\"Mailbox Entrada\","
                + "\"_id\":\"abc-123-xyz\","
                + "\"_score\":1.0,"
                + "\"robot_str\":[{\"task_priority_type\":\"LOW\"}]"
                + "}";

        // Al deserializar, la propiedad FAIL_ON_UNKNOWN_PROPERTIES=false evitará que lance una excepción
        CU83CourtOrderDTO resultado = objectMapper.readValue(jsonDesdeElastic, CU83CourtOrderDTO.class);

        assertThat(resultado).isNotNull();
        assertThat(resultado.getMailboxDesc()).isEqualTo("Mailbox Entrada");
        assertThat(resultado.getRobotStr().get(0).getTaskPriorityType()).isEqualTo("LOW");
    }

}
