package com.bbva.smre.lib.ru83.impl.local;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.internal.util.reflection.Whitebox;
//-import org.osgi.framework.Bundle-

import com.bbva.elara.configuration.manager.application.ApplicationConfigurationService;
import com.bbva.elara.domain.transaction.Context;
import com.bbva.elara.domain.transaction.RequestHeaderParamsName;
import com.bbva.elara.domain.transaction.ThreadContext;
import com.bbva.elara.domain.transaction.request.TransactionRequest;
import com.bbva.elara.domain.transaction.request.body.CommonRequestBody;
import com.bbva.elara.domain.transaction.request.header.CommonRequestHeader;
//-import com.bbva.elara.test.osgi.DummyBundleContext-


import com.bbva.smre.dto.cu83.CU83CourtOrderDTO;
import com.bbva.smre.lib.ru83.helpers.Validations;
import com.bbva.smre.lib.ru83.local.ConfigTest;

import com.bbva.smre.lib.ru83.local.ElasticHelper;
import com.bbva.smre.lib.ru83.values.SMRERU83Constants;

public class SMRERU83ImplTestLoc {
	
	
	
	//@Mock-
	//private DummyBundleContext bundleContext-
	@Mock
	private CommonRequestHeader commonRequestHeader;

	@Mock
	TransactionRequest transactionRequest;

	@Mock
	Context context;
	
	
	
	@Mock
	ApplicationConfigurationService applicationConfigurationService;
	
	
	@Before
	public void setUp() throws Exception{
		MockitoAnnotations.initMocks(this);
		CommonRequestBody body = new CommonRequestBody();
		body.setTransactionParameters(new ArrayList<>());
		transactionRequest.setBody(body);
		transactionRequest.setHeader(commonRequestHeader);
		context.setTransactionRequest(transactionRequest);
		 context = new Context();
	        context.setTransactionRequest(this.setHeaders());
		ThreadContext.set(context);
		//-Bundle bundle = Mockito.mock(Bundle.class)-
		//-Mockito.when(bundleContext.getBundle()).thenReturn(bundle)-
	}
	
	 private TransactionRequest setHeaders() {
	        TransactionRequest tRequest = new TransactionRequest();
	        Map<RequestHeaderParamsName, Object> headerParamsMap = new EnumMap<>(RequestHeaderParamsName.class);

	        headerParamsMap.put(RequestHeaderParamsName.USERCODE, "XE73372");
	        headerParamsMap.put(RequestHeaderParamsName.LANGUAGECODE, "es");
	        headerParamsMap.put(RequestHeaderParamsName.OPERATIVEENTITYCODE, "0182");
	        CommonRequestHeader header = new CommonRequestHeader();
	        Whitebox.setInternalState(header, "headerParamsMap", headerParamsMap);
	        CommonRequestBody body = new CommonRequestBody();
	        body.setTransactionParameters(new ArrayList<>());
	        tRequest.setHeader(header);
	        tRequest.setBody(body);
	        return tRequest;
	    }
	
    @Test
	public void testConfig()  {

    
	
		Mockito.when(applicationConfigurationService.getProperty(SMRERU83Constants.CAPX_RUN_MODE)).thenReturn("LOCAL");
	
	//	ih.setCrh(commonRequestHeader);

		Mockito.when(commonRequestHeader.getHeaderParameter(RequestHeaderParamsName.USERCODE)).thenReturn("Y927293");

		
		Validations val = new Validations(new ArrayList<>());
		ConfigTest.initElas( applicationConfigurationService, null, val);
			
		Assert.assertTrue(true);
	}
    
    
    
    @Test
	public void testElaLocal()  {
    	String IdExpedienteJudicial = "000000";
    	
    	Validations val = new Validations(new ArrayList<>());
    	ElasticHelper eh = new ElasticHelper(applicationConfigurationService, null, val);
    	CU83CourtOrderDTO dto = new CU83CourtOrderDTO();
    	dto.setMailboxDesc("oficios-ia@dev.bbva.com");
    	dto.setMailUniqId("12345666");
    	dto.setJudicialFileId(IdExpedienteJudicial);
    	
    	eh.insertarDocumento(dto);
    	eh.buscarPorIdExpedienteJudicial(IdExpedienteJudicial);
    }
}
