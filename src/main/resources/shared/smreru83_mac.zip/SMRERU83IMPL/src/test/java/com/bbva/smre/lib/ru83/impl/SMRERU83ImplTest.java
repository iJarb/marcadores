package com.bbva.smre.lib.ru83.impl;

import com.bbva.elara.domain.transaction.Context;
import com.bbva.elara.domain.transaction.ThreadContext;
import com.bbva.elara.utility.api.connector.APIConnector;
import com.bbva.smre.dto.cu83.CU83IssueDTO;
import com.bbva.smre.lib.ru83.helpers.ConfigBbva;
import com.bbva.smre.lib.ru83.helpers.ElasticResponse;
import com.bbva.smre.lib.ru83.helpers.Validations;
import com.bbva.smre.lib.ru83.local.MapperElastic;
import com.bbva.smre.lib.ru83.utils.Utils;
import com.bbva.smre.lib.ru83.values.SMRERU83Constants;
import com.google.gson.JsonObject;
import com.bbva.elara.configuration.manager.application.ApplicationConfigurationService;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class SMRERU83ImplTest {

	private static final String ID_MAIL = "12345678901";
	
	private static final String ELAS_RES_JSON = "{"
            + "\"_source\": {"
            + "  \"_id\": \"idmail-001\","
            + "  \"regulatory_organism_desc\": \"BANCO DE ESPAÑA\","
            + "  \"taxonomy_reason_id\": \"1599\","
            + "  \"complaint_id\": 12063338,"
            + "  \"loc_pu_org_ref_id_str\": [{\"document_desc\": \"doc1.pdf\", \"document_page_number\": 1}],"
            + "  \"loc_comp_id_str\": [{\"document_desc\": \"doc2.pdf\", \"document_page_number\": -1}],"
            + "  \"comp_str\": [{"
            + "    \"internal_intervention_type_desc\": \"RECLAMANTE\","
            + "    \"personal_type_desc\": \"NIF PERSONA FISICA\","
            + "    \"personal_id\": \"04140690Y\","
            + "    \"customer_complete_name\": \"KAHLAN AMNELL\","
            + "    \"email_desc\": \"kahlan@tierrascentrales.com\","
            + "    \"loc_pers_id_str\": [{\"document_desc\": \"KahlanAmnell.pdf\", \"document_page_number\": 1}],"
            + "    \"loc_cus_compl_name_str\": [{\"document_desc\": \"KahlanAmnell_2.pdf\", \"document_page_number\": 1}],"
            + "    \"loc_email_str\": [{\"document_desc\": \"KahlanAmnell_3.pdf\", \"document_page_number\": 2}]"
            + "  }],"
            + "  \"isses_str\": [{"
            + "    \"total_claim_amount\": \"1500.50\","
            + "    \"currency_id\": \"EUR\","
            + "    \"entry_settlement_date\": \"2025-03-06\","
            + "    \"blind_pan_id\": \"************4393\","
            + "    \"ccc_str\": {\"external_contract_id\": \"4512232586510993\"},"
            + "    \"taxo_str\": {\"complaint_taxonomy_id\": 1599, \"complaint_taxonomy_desc\": \"TARJETAS REVOLVING\"},"
            + "    \"loc_claim_amont_str\": [{\"document_desc\": \"doc3.pdf\", \"document_page_number\": 1}],"
            + "    \"loc_con_id_str\": [{\"document_desc\": \"doc4.pdf\", \"document_page_number\": 1}],"
            + "    \"loc_exec_date_str\": [{\"document_desc\": \"doc5.pdf\", \"document_page_number\": 1}],"
            + "    \"loc_pan_ofus_cont_id_str\": [{\"document_desc\": \"doc6.pdf\", \"document_page_number\": 1}]"
            + "  }]"
            + "}"
            + "}";


	
	@Mock
	private ApplicationConfigurationService applicationConfigurationService;


	@InjectMocks
	private SMRERU83Impl smreRU83;
	
	
	@Mock
	APIConnector internalApiConnector;


	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		ThreadContext.set(new Context());
	}

	@Test
	public void executeTest(){

		smreRU83.executeGetCourtOrder(ID_MAIL);
		smreRU83.executeInsertCourtOrderCoordinates(null);
		
		Assert.assertEquals(0, smreRU83.getAdviceList().size());
	}
	
	@Test
    public void testElasticConfigIncompleteReturnsNull() {
      
        when(applicationConfigurationService.getProperty(SMRERU83Constants.ELASTIC_URL)).thenReturn(null);
        when(applicationConfigurationService.getProperty(SMRERU83Constants.ELASTIC_INDEX)).thenReturn(null);
        when(applicationConfigurationService.getProperty(SMRERU83Constants.ELASTIC_DOC_PATH)).thenReturn(null);

        smreRU83.executeGetCourtOrder(ID_MAIL);
        Assert.assertTrue(true);
    }
	
	@Test
    public void testElasticConfigCompleteReturnsNull() {
      
        when(applicationConfigurationService.getProperty(SMRERU83Constants.ELASTIC_URL)).thenReturn("http://elastic:9200");
        when(applicationConfigurationService.getProperty(SMRERU83Constants.ELASTIC_INDEX)).thenReturn("complaints");
        when(applicationConfigurationService.getProperty(SMRERU83Constants.ELASTIC_DOC_PATH)).thenReturn("/_doc/");

        com.bbva.smre.dto.cu83.CU83CourtOrderDTO coordinates = new com.bbva.smre.dto.cu83.CU83CourtOrderDTO();
        coordinates.setMailboxDesc("a@b.nonamed");
        
        List<CU83IssueDTO> issues = new ArrayList<>();
        CU83IssueDTO ipc = new CU83IssueDTO();
        
        
        Map<String,String> taxonomy = new HashMap<>();
        taxonomy.put("taxonomyId", "");
        
        issues.add(ipc);
        coordinates.setIssesStr(issues);
        
        
        smreRU83.executeInsertCourtOrderCoordinates(coordinates);
        Assert.assertEquals(0, smreRU83.getAdviceList().size());
    }

    @Test
    public void testElasticBodyNullReturnsNull() {
       
        when(applicationConfigurationService.getProperty(SMRERU83Constants.ELASTIC_URL)).thenReturn("http://elastic:9200");
        when(applicationConfigurationService.getProperty(SMRERU83Constants.ELASTIC_INDEX)).thenReturn("complaints");
        when(applicationConfigurationService.getProperty(SMRERU83Constants.ELASTIC_DOC_PATH)).thenReturn("/_doc/");
        when(internalApiConnector.exchange(anyString(), eq(HttpMethod.GET), any(), eq(String.class)))
                .thenReturn(new ResponseEntity<>(null, HttpStatus.OK));

        smreRU83.executeGetCourtOrder(ID_MAIL);
        Assert.assertTrue(true);
    }


    @Test
    public void testFullElasticResponseMapsCorrectly() {
        
        String elasticJson =ELAS_RES_JSON;

        when(applicationConfigurationService.getProperty(SMRERU83Constants.ELASTIC_URL)).thenReturn("http://elastic:9200");
        when(applicationConfigurationService.getProperty(SMRERU83Constants.ELASTIC_INDEX)).thenReturn("complaints");
        when(applicationConfigurationService.getProperty(SMRERU83Constants.ELASTIC_DOC_PATH)).thenReturn("/_doc/");
        when(internalApiConnector.exchange(anyString(), eq(HttpMethod.GET), any(), eq(String.class)))
                .thenReturn(new ResponseEntity<>(elasticJson, HttpStatus.OK));

        List<com.bbva.smre.dto.cu83.CU83CourtOrderDTO> result = smreRU83.executeGetCourtOrder(ID_MAIL);

        if(SMRERU83Constants.RUN_MODE.equals("LOCAL")) {			
			return;
		}
        
        Assert.assertNotNull(result);
        
    }

    @Test
    public void testSourceMissingReturnsNull() {
        String elasticJson = "{\"_index\": \"complaints\"}";

        
        when(applicationConfigurationService.getProperty(SMRERU83Constants.ELASTIC_URL)).thenReturn("http://elastic:9200");
        when(applicationConfigurationService.getProperty(SMRERU83Constants.ELASTIC_INDEX)).thenReturn("complaints");
        when(applicationConfigurationService.getProperty(SMRERU83Constants.ELASTIC_DOC_PATH)).thenReturn("/_doc/");
        when(internalApiConnector.exchange(anyString(), eq(HttpMethod.GET), any(), eq(String.class)))
                .thenReturn(new ResponseEntity<>(elasticJson, HttpStatus.OK));

        smreRU83.executeGetCourtOrder(ID_MAIL);
        Assert.assertTrue(true);
    }
	
	@Test
    public void testEmptyArraysAndNullFieldsNoNpe() {
     
       
        when(applicationConfigurationService.getProperty(SMRERU83Constants.ELASTIC_URL)).thenReturn("http://elastic:9200");
        when(applicationConfigurationService.getProperty(SMRERU83Constants.ELASTIC_INDEX)).thenReturn("complaints");
        when(applicationConfigurationService.getProperty(SMRERU83Constants.ELASTIC_DOC_PATH)).thenReturn("/_doc/");
  
       
        smreRU83.setInternalApiConnector(internalApiConnector); 
        ElasticResponse mockResponse = new ElasticResponse();
        ResponseEntity<ElasticResponse> responseEntityMock = new ResponseEntity<>(mockResponse, HttpStatus.OK);

        doReturn(responseEntityMock)
            .when(internalApiConnector)
            .postForEntity(
                anyString(),          
                any(),                
                eq(ElasticResponse.class), 
                any(Object[].class)    
            );
        
        List<com.bbva.smre.dto.cu83.CU83CourtOrderDTO> result = smreRU83.executeGetCourtOrder(ID_MAIL);

        if(SMRERU83Constants.RUN_MODE.equals("LOCAL")) {			
			return;
		}
        
        Assert.assertNotNull(result);
    }
	
	 @Test
	 public void testUtilNullObjectReturnsDefaults() {
	        Assert.assertNull(Utils.getTextValue(null, "field"));
	        Assert.assertNull(Utils.getObject(null, "field"));
	        Assert.assertNull(Utils.getArray(null, "field"));
	        Assert.assertEquals(99, Utils.getIntValue(null, "field", 99));
	        Assert.assertNull(Utils.getLongValue(null, "field"));


	        JsonObject empty = new JsonObject();
	        Assert.assertNull(Utils.getTextValue(empty, "missing"));
	        Assert.assertNull(Utils.getObject(empty, "missing"));
	        Assert.assertNull(Utils.getArray(empty, "missing"));
	        Assert.assertEquals(-1, Utils.getIntValue(empty, "missing", -1));
	        Assert.assertNull(Utils.getLongValue(empty, "missing"));


	        JsonObject withNull = Utils.parseJson("{\"f\": null}");
	        Assert.assertNull(Utils.getTextValue(withNull, "f"));
	        Assert.assertNull(Utils.getObject(withNull, "f"));
	        Assert.assertNull(Utils.getArray(withNull, "f"));
	        Assert.assertEquals(0, Utils.getIntValue(withNull, "f", 0));
	        Assert.assertNull(Utils.getLongValue(withNull, "f"));
	        
	        Utils.getStrProp(applicationConfigurationService, null, null);
	        Utils.getStrProp(null, "property", null);
	        Utils.getStrProp(null,null, null);
	        
	        ConfigBbva.initElas(applicationConfigurationService, internalApiConnector, new Validations(new ArrayList<>()));        
	        
	    }
	 

}