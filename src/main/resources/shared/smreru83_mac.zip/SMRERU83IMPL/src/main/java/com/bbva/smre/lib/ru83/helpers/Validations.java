package com.bbva.smre.lib.ru83.helpers;

import java.util.List;

import com.bbva.smre.dto.cu83.CU83CourtOrderDTO;
import com.bbva.smre.lib.ru83.values.SMRERU83Errors;



public class Validations {

	
	private List<String> errors; 
	
	public Validations(List<String> args) {
		this.errors=args;
	}
	
	public boolean validateParmIn(CU83CourtOrderDTO  cpc) {

		if (cpc == null || cpc.getMailboxDesc() == null || cpc.getMailUniqId() == null || cpc.getMailboxDesc().length() < 10 || cpc.getMailUniqId().length() < 10) {
			addAdviceFunctional(SMRERU83Errors.LOS_DATOS_INFORMADOS_NO_SON_CORRECTOS);
			return false;
		}

		return true;

	}
	
	public boolean validateParmIn(String id) {

		if (id == null || id.length() <10) {
			addAdviceFunctional(SMRERU83Errors.LOS_DATOS_INFORMADOS_NO_SON_CORRECTOS);
			return false;
		}

		return true;

	}
       
    public void addAdviceFunctional(String adviceCode) {
    	
    		errors.add(adviceCode);
    	
    	
    }

	public List<String> getErrors() {
		return errors;
	}    
	
	
	
    
}
