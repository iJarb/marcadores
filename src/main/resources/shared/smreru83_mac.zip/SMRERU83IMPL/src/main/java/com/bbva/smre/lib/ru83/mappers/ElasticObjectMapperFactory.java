package com.bbva.smre.lib.ru83.mappers;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.util.StdDateFormat;

public class ElasticObjectMapperFactory {
	
	public static ObjectMapper createObjectMapper() {
        ObjectMapper mapper = new ObjectMapper();

        // 1. Evita incluir campos 'null' en el JSON saliente (Evita errores en dynamic: strict)
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);

        // 2. Configura las fechas en formato estándar ISO-8601 (yyyy-MM-dd'T'HH:mm:ss.SSSX)
        // Por defecto, Jackson convierte Date a timestamps numéricos (long), lo cual rompería tu mapeo de fechas.
        mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        mapper.setDateFormat(new StdDateFormat().withColonInTimeZone(true));

        // 3. Tolerancia a fallos en la lectura (Deserialización)
        // Si Elasticsearch devuelve campos extras en los hits, la aplicación no arrojará UnrecognizedPropertyException
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        return mapper;
    }

}
