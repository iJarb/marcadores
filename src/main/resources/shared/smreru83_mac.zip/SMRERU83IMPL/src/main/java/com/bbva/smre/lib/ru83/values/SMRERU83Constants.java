package com.bbva.smre.lib.ru83.values;

public class SMRERU83Constants {

	private SMRERU83Constants() {

	}

	public static final String SEM_LOG = "SMRERU83";
	public static final String RUN_MODE = "LOCAL"; // APX o LOCAL
	
	public static final String  CAPX_RUN_MODE    = "smreru83.runMode";
	public static final String  CAPX_RUN_MODE_DV = RUN_MODE;
	
	
	// Elasticsearch
	public static final String ELASTIC_API      = "elastic.BEL_SMRE";
    public static final String ELASTIC_URL      = "smrerf10.elastic.url";
    public static final String ELASTIC_INDEX    = "smrerf10.elastic.index";
    public static final String ELASTIC_DOC_PATH = "smrerf10.elastic.doc";


    // Elasticsearch - campos raíz del documento
    public static final String FIELD_SOURCE                  = "_source";
    public static final String FIELD_ID                      = "_id";
    public static final String FIELD_REGULATORY_ORGANISM     = "regulatory_organism_desc";
    public static final String FIELD_LOC_PU_ORG_REF          = "loc_pu_org_ref_id_str";
    public static final String FIELD_TAXONOMY_REASON         = "taxonomy_reason_id";
    public static final String FIELD_COMPLAINT_ID            = "complaint_id";
    public static final String FIELD_LOC_COMP_ID             = "loc_comp_id_str";
    public static final String FIELD_COMP_STR                = "comp_str";
    public static final String FIELD_ISSES_STR               = "isses_str";

    // Elasticsearch - campos de complainant (comp_str)
    public static final String FIELD_INTERVENTION_TYPE       = "internal_intervention_type_desc";
    public static final String FIELD_PERSONAL_TYPE           = "personal_type_desc";
    public static final String FIELD_PERSONAL_ID             = "personal_id";
    public static final String FIELD_LOC_PERS_ID             = "loc_pers_id_str";
    public static final String FIELD_CUSTOMER_NAME           = "customer_complete_name";
    public static final String FIELD_LOC_CUSTOMER_NAME       = "loc_cus_compl_name_str";
    public static final String FIELD_EMAIL                   = "email_desc";
    public static final String FIELD_LOC_EMAIL               = "loc_email_str";

    // Elasticsearch - campos de issue (isses_str)
    public static final String FIELD_TOTAL_CLAIM_AMOUNT      = "total_claim_amount";
    public static final String FIELD_CURRENCY                = "currency_id";
    public static final String FIELD_LOC_CLAIM_AMOUNT        = "loc_claim_amont_str";
    public static final String FIELD_LOC_CON_ID              = "loc_con_id_str";
    public static final String FIELD_ENTRY_SETTLEMENT_DATE   = "entry_settlement_date";
    public static final String FIELD_LOC_EXEC_DATE           = "loc_exec_date_str";
    public static final String FIELD_BLIND_PAN               = "blind_pan_id";
    public static final String FIELD_LOC_PAN                 = "loc_pan_ofus_cont_id_str";
    public static final String FIELD_TAXO_STR                = "taxo_str";

    // Elasticsearch - campos de contrato (ccc_str)
    public static final String FIELD_CCC_STR                 = "ccc_str";
    public static final String FIELD_EXTERNAL_CONTRACT_ID    = "external_contract_id";

    // Elasticsearch - campos de taxonomía (taxo_str)
    public static final String FIELD_TAXONOMY_ID             = "complaint_taxonomy_id";
    public static final String FIELD_TAXONOMY_DESC           = "complaint_taxonomy_desc";

    // Elasticsearch - campos de location
    public static final String FIELD_DOCUMENT_DESC           = "document_desc";
    public static final String FIELD_DOCUMENT_PAGE_NUMBER    = "document_page_number";
    
    
    
    // Elasticsearch fields
 	public static final String COMPLAINANTS = "comp_str";
 	public static final String INTERVENTION_TYPE = "internal_intervention_type_desc";
 	public static final String IDENTIFICATION_TYPE = "personal_type_desc";
 	public static final String IDENTIFICATION_NUMBER = "personal_id";
 	public static final String EMAIL = "email_desc";
 	public static final String LEGAL_NAME = "customer_complete_name";	
 	public static final String LOCATION_IDENTIFICATION_NUMBER = "loc_pers_id_str";
 	public static final String LOCATION_EMAIL = "loc_email_str";
 	public static final String LOCATION_LEGAL_NAME = "loc_cus_compl_name_str";
 	
 	public static final String ISSUES = "isses_str";
 	public static final String CLAIMED_AMOUNT = "total_claim_amount";
 	public static final String CURRENCY = "currency_id";
 	public static final String CONTRACT_TYPE_DESC = "contract_type_desc";
 	public static final String SETTLEMENT_DATE = "entry_settlement_date";
 	public static final String TAXONOMY = "taxo_str";
 	public static final String TAXONOMY_ALIAS = "complaint_taxonomy_desc";
 	public static final String TAXONOMY_KEY = "complaint_taxonomy_id";
 	public static final String OBFUSCATED_PAN = "blind_pan_id";
 	public static final String CONTRACT = "con_id_str";
 	public static final String CONTRACT_ID = "contract_id";
 	public static final String LOCATION_CLAIMED_AMOUNT = "loc_claim_amont_str";
 	public static final String LOCATION_SETTLEMENT_DATE = "loc_exec_date_str";
 	public static final String LOCATION_OBFUSCATED_PAN = "loc_pan_ofus_cont_id_str";
 	public static final String LOCATION_CONTRACT = "loc_con_id_str";
 	
 	public static final String REPRESENTATIVE_ORGANIZATION = "regulatory_organism_desc";
 	public static final String LOCATION_REPRESENTATIVE_ORGANIZATION = "loc_pu_org_ref_id_str";
 	
 	public static final String LINKED_COMPLAINT = "complaint_id";
 	public static final String LOCATION_LINKED_COMPLAIT = "loc_comp_id_str";
 	
 	public static final String COMPLAINT_REASON_ID = "taxonomy_reason_id";
 	
 	public static final String DOCS = "document_desc";
 	public static final String PAGES = "document_page_number";
 	
 	public static final String AUDIT_DATE = "audit_date";
 	public static final String AUDIT_USER = "audit_user_id";
 	
 	public static final String ID = "_id";
 	public static final String INDEX = "index";
 	public static final String ELASTIC_API_DB = "elastic.BEL_SMRE_ES";


}
