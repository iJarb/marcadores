package com.bbva.smre.lib.ru83.impl;

import com.bbva.elara.configuration.manager.application.ApplicationConfigurationService;
import com.bbva.elara.library.AbstractLibrary;
import com.bbva.elara.utility.api.connector.APIConnector;
import com.bbva.smre.lib.ru83.SMRERU83;

/**
 * This class automatically defines the libraries and utilities that it will use.
 */
public abstract class SMRERU83Abstract extends AbstractLibrary implements SMRERU83 {

	protected ApplicationConfigurationService applicationConfigurationService;

	protected APIConnector internalApiConnector;


	public void setApplicationConfigurationService(ApplicationConfigurationService applicationConfigurationService) {
		this.applicationConfigurationService = applicationConfigurationService;
	}

	public void setInternalApiConnector(APIConnector internalApiConnector) {
		this.internalApiConnector = internalApiConnector;
	}

}