package com.bbva.smre.lib.ru83.local;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.LoggerFactory;

import com.bbva.elara.utility.api.connector.APIConnector;
import com.bbva.elara.configuration.manager.application.ApplicationConfigurationService;
import com.bbva.smre.dto.cu83old.CU83ComplainantDTO;
import com.bbva.smre.dto.cu83old.CU83Contract;
import com.bbva.smre.dto.cu83old.CU83CourtOrderDTO;
import com.bbva.smre.dto.cu83old.CU83IdentifierEntity;
import com.bbva.smre.dto.cu83old.CU83IssueDTO;
import com.bbva.smre.dto.cu83old.CU83LocationDTO;
import com.bbva.smre.dto.cu83old.CU83PayAmount;
import com.bbva.smre.dto.cu83old.CU83RelatedCourtOrder;
import com.bbva.smre.dto.cu83old.CU83TaxonomyDTO;
import com.bbva.smre.dto.cu83old.coordinates.C83CourtOrderPositioningCoordinates;
import com.bbva.smre.dto.cu83old.coordinates.CU83ComplainantPositioningCoordinates;
import com.bbva.smre.dto.cu83old.coordinates.CU83IssuePositioningCoordinates;
import com.bbva.smre.dto.cu83old.coordinates.CU83Location;
import com.bbva.smre.dto.cu83old.coordinates.CU83PositioningCoordinates;

import com.bbva.smre.lib.ru83.utils.Utils;
import com.bbva.smre.lib.ru83.values.SMRERU83Constants;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;



public class MapperElastic {

	private static final org.slf4j.Logger log = LoggerFactory.getLogger(MapperElastic.class);
	
	ApplicationConfigurationService acs;
	APIConnector                    internalApiConnector;
	
	public MapperElastic(ApplicationConfigurationService acs) {
		this.acs=acs;
	}
	
	
	public CU83CourtOrderDTO mapElasticResponseToComplaintDTO(String elasticResponse) {
        tl(SMRERU83Constants.SEM_LOG+"mapElasticResponseToComplaintDTO");
        if(elasticResponse == null) {
        	tl(SMRERU83Constants.SEM_LOG+"Respuesta de Elastic nula");
            return null;
        }

        JsonObject root = Utils.parseJson(elasticResponse);
        JsonObject source = Utils.getObject(root, SMRERU83Constants.FIELD_SOURCE);

        if (source == null) {
        	tl(SMRERU83Constants.SEM_LOG+"_source no encontrado en respuesta Elastic");
            return null;
        }

        CU83CourtOrderDTO dto = new CU83CourtOrderDTO();
        dto.setId(Utils.getTextValue(source, SMRERU83Constants.FIELD_ID));
        dto.setPublicOrganismReference(Utils.getTextValue(source, SMRERU83Constants.FIELD_REGULATORY_ORGANISM));
        dto.setPublicOrganismReferenceLoc(mapLocationDTO(Utils.getArray(source, SMRERU83Constants.FIELD_LOC_PU_ORG_REF)));
        dto.setReasonCodeId(Utils.getTextValue(source, SMRERU83Constants.FIELD_TAXONOMY_REASON));
        dto.setCourtOrderIdLoc(mapLocationDTO(Utils.getArray(source, SMRERU83Constants.FIELD_LOC_COMP_ID)));
        dto.setRelatedCourtOrder(mapRelatedComplaint(source));
        dto.setComplainants(mapComplainants(Utils.getArray(source, SMRERU83Constants.FIELD_COMP_STR)));
        dto.setIssues(mapIssues(Utils.getArray(source, SMRERU83Constants.FIELD_ISSES_STR)));

        tl(SMRERU83Constants.SEM_LOG+"Mapper completado: "+ dto);
        return dto;
    }
	
	private CU83LocationDTO mapLocationDTO(JsonArray locArray) {
        if (locArray == null || locArray.size() == 0) {
            return null;
        }

        List<String> documents = new ArrayList<>();
        List<List<Integer>> pages = new ArrayList<>();

        for (int i = 0; i < locArray.size(); i++) {
            JsonObject locNode = locArray.get(i).getAsJsonObject();
            documents.add(Utils.getTextValue(locNode, SMRERU83Constants.FIELD_DOCUMENT_DESC));

            int pageNumber = Utils.getIntValue(locNode, SMRERU83Constants.FIELD_DOCUMENT_PAGE_NUMBER, -1);
            if (pageNumber >= 0) {
                pages.add(Collections.singletonList(pageNumber));
            } else {
                pages.add(Collections.emptyList());
            }
        }

        CU83LocationDTO dto = new CU83LocationDTO();
        dto.setDocuments(documents);
        dto.setPages(pages);
        return dto;
    }
	
	private CU83RelatedCourtOrder mapRelatedComplaint(JsonObject source) {
        Long complaintId = Utils.getLongValue(source, SMRERU83Constants.FIELD_COMPLAINT_ID);
        if (complaintId == null) {
            return null;
        }
        CU83RelatedCourtOrder relatedCourtOrder = new CU83RelatedCourtOrder();
        relatedCourtOrder.setCourtOrderId(complaintId);
        return relatedCourtOrder;
    }
	
	private List<CU83ComplainantDTO> mapComplainants(JsonArray array) {
        if (array == null || array.size() == 0) {
            return Collections.emptyList();
        }
        List<CU83ComplainantDTO> list = new ArrayList<>();
        for (int i = 0; i < array.size(); i++) {
            list.add(mapComplainant(array.get(i).getAsJsonObject()));
        }
        return list;
    }
	 private List<CU83IssueDTO> mapIssues(JsonArray array) {
	        if (array == null || array.size() == 0) {
	            return Collections.emptyList();
	        }
	        List<CU83IssueDTO> list = new ArrayList<>();
	        for (int i = 0; i < array.size(); i++) {
	            list.add(mapIssue(array.get(i).getAsJsonObject()));
	        }
	        return list;
	    }

	    private CU83IssueDTO mapIssue(JsonObject node) {
	        CU83IssueDTO dto = new CU83IssueDTO();

	        String amount = Utils.getTextValue(node, SMRERU83Constants.FIELD_TOTAL_CLAIM_AMOUNT);
	        String currency = Utils.getTextValue(node, SMRERU83Constants.FIELD_CURRENCY);
	        if (amount != null || currency != null) {
	            CU83PayAmount payAmount = new CU83PayAmount();
	            if (amount != null) {
	                payAmount.setAmount(Double.valueOf(amount));
	            }
	            payAmount.setCurrency(currency);
	            dto.setClaimedAmount(payAmount);
	        }

	        dto.setClaimedAmountLoc(mapLocationDTO(Utils.getArray(node, SMRERU83Constants.FIELD_LOC_CLAIM_AMOUNT)));
	        dto.setContract(mapContract(node));
	        dto.setContractLoc(mapLocationDTO(Utils.getArray(node, SMRERU83Constants.FIELD_LOC_CON_ID)));
	        dto.setExecutionDate(Utils.getTextValue(node, SMRERU83Constants.FIELD_ENTRY_SETTLEMENT_DATE));
	        dto.setExecutionDateLoc(mapLocationDTO(Utils.getArray(node, SMRERU83Constants.FIELD_LOC_EXEC_DATE)));
	        dto.setOfuscatedPanId(Utils.getTextValue(node, SMRERU83Constants.FIELD_BLIND_PAN));
	        dto.setOfuscatedPanIdLoc(mapLocationDTO(Utils.getArray(node, SMRERU83Constants.FIELD_LOC_PAN)));
	        dto.setTaxonomy(mapTaxonomy(Utils.getObject(node, SMRERU83Constants.FIELD_TAXO_STR)));

	        return dto;
	    }
	    
	    //Todos los tipos de contratos se van a guardar dentro de ccc_str, por lo que se mapea directamente desde ahí
	    private CU83Contract mapContract(JsonObject issueNode) {
	        JsonObject contractId = Utils.getObject(issueNode, SMRERU83Constants.FIELD_CCC_STR);

	        CU83Contract contract = new CU83Contract();
	        contract.setProductId(Utils.getTextValue(contractId, SMRERU83Constants.FIELD_EXTERNAL_CONTRACT_ID));

	        return contract;
	    }


	    private CU83TaxonomyDTO mapTaxonomy(JsonObject taxoNode) {
	        if (taxoNode == null) {
	            return null;
	        }
	        CU83TaxonomyDTO dto = new CU83TaxonomyDTO();
	        dto.setTaxonomyId(Utils.getTextValue(taxoNode, SMRERU83Constants.FIELD_TAXONOMY_ID));
	        dto.setTaxonomyDesc(Utils.getTextValue(taxoNode, SMRERU83Constants.FIELD_TAXONOMY_DESC));
	        return dto;
	    }
	    
	    private CU83ComplainantDTO mapComplainant(JsonObject node) {
	        CU83ComplainantDTO dto = new CU83ComplainantDTO();

	        String interventionDesc = Utils.getTextValue(node, SMRERU83Constants.FIELD_INTERVENTION_TYPE);
	        if (interventionDesc != null) {
	            dto.setInterventionType(new CU83IdentifierEntity(null, interventionDesc));
	        }

	        String personalTypeDesc = Utils.getTextValue(node, SMRERU83Constants.FIELD_PERSONAL_TYPE);
	        String personalId = Utils.getTextValue(node, SMRERU83Constants.FIELD_PERSONAL_ID);
	        if (personalTypeDesc != null || personalId != null) {
	            dto.setIndentificationType(new CU83IdentifierEntity(personalId, personalTypeDesc));
	        }

	        dto.setIdentificationTypeLoc(mapLocationDTO(Utils.getArray(node, SMRERU83Constants.FIELD_LOC_PERS_ID)));
	        dto.setCustomerCompleteName(Utils.getTextValue(node, SMRERU83Constants.FIELD_CUSTOMER_NAME));
	        dto.setCustomerCompleteNameLoc(mapLocationDTO(Utils.getArray(node, SMRERU83Constants.FIELD_LOC_CUSTOMER_NAME)));
	        dto.setEmail(Utils.getTextValue(node, SMRERU83Constants.FIELD_EMAIL));
	        dto.setEmailLoc(mapLocationDTO(Utils.getArray(node, SMRERU83Constants.FIELD_LOC_EMAIL)));

	        return dto;
	    }
	    
	    
        
	    public String buildJsonElastic(C83CourtOrderPositioningCoordinates courtOrderCoordinates) {
			
			Map<String, Object> mapComplaintCoordinates = new HashMap<>();
			
			// Complainants
			List<Map<String, Object>> complainants = new ArrayList<>();
			for (CU83ComplainantPositioningCoordinates complainant : courtOrderCoordinates.getComplainants()) {
				
				Map<String, Object> complainantElastic = new HashMap<>();
				
				complainantElastic.put(SMRERU83Constants.INTERVENTION_TYPE, complainant.getInterventionType());
				complainantElastic.put(SMRERU83Constants.IDENTIFICATION_TYPE, complainant.getIdentificationType());
				complainantElastic.put(SMRERU83Constants.IDENTIFICATION_NUMBER, complainant.getIdentificationNumber().getValue());
				complainantElastic.put(SMRERU83Constants.LEGAL_NAME, complainant.getLegalName().getValue());
				complainantElastic.put(SMRERU83Constants.EMAIL, complainant.getEmail().getValue());
				
				// Retrieve the positioning coordinates (documents and pages) where the IA Agent has found and extracted each of the following fields
				complainantElastic.put(SMRERU83Constants.LOCATION_IDENTIFICATION_NUMBER, getFieldLocations(complainant.getIdentificationNumber()));
				complainantElastic.put(SMRERU83Constants.LOCATION_LEGAL_NAME, getFieldLocations(complainant.getLegalName()));
				complainantElastic.put(SMRERU83Constants.LOCATION_EMAIL, getFieldLocations(complainant.getEmail()));
				
				complainants.add(complainantElastic);
			}
			mapComplaintCoordinates.put(SMRERU83Constants.COMPLAINANTS, complainants);
			
			// Issues
			List<Map<String, Object>> issues = new ArrayList<>();
			for (CU83IssuePositioningCoordinates issue : courtOrderCoordinates.getIssues()) {
				
				Map<String, Object> issueElastic = new HashMap<>();
				
				issueElastic.put(SMRERU83Constants.CLAIMED_AMOUNT, issue.getClaimedAmount().getValue());
				issueElastic.put(SMRERU83Constants.CURRENCY, issue.getCurrency().getValue());
				issueElastic.put(SMRERU83Constants.CONTRACT_TYPE_DESC, issue.getContractIdentifierType().getValue());
				
				Map<String, Object> taxonomy = new HashMap<>();
				taxonomy.put(SMRERU83Constants.TAXONOMY_KEY, issue.getTaxonomy().keySet().iterator().next());
				taxonomy.put(SMRERU83Constants.TAXONOMY_ALIAS, issue.getTaxonomy().values().iterator().next());
				issueElastic.put(SMRERU83Constants.TAXONOMY, taxonomy);
				
				String settlementDate = StringUtils.isBlank(issue.getFormalizationDate().getValue()) ? "1900-01-01" : issue.getFormalizationDate().getValue();
				issueElastic.put(SMRERU83Constants.SETTLEMENT_DATE, settlementDate);
				issueElastic.put(SMRERU83Constants.OBFUSCATED_PAN, issue.getObfuscatedPan() != null ? issue.getObfuscatedPan().getValue() : null);
				
				Map<String, Object> contract = new HashMap<>();
				contract.put(SMRERU83Constants.CONTRACT_ID, issue.getContractIdentifierNumber().getValue());
				issueElastic.put(SMRERU83Constants.CONTRACT, contract);
				
				// Retrieve the positioning coordinates (documents and pages) where the IA Agent has found and extracted each of the following fields
				issueElastic.put(SMRERU83Constants.LOCATION_CLAIMED_AMOUNT, getFieldLocations(issue.getClaimedAmount()));
				issueElastic.put(SMRERU83Constants.LOCATION_SETTLEMENT_DATE, getFieldLocations(issue.getFormalizationDate()));
				issueElastic.put(SMRERU83Constants.LOCATION_OBFUSCATED_PAN, getFieldLocations(issue.getObfuscatedPan()));
				issueElastic.put(SMRERU83Constants.LOCATION_CONTRACT, getFieldLocations(issue.getContractIdentifierNumber()));
				
				issues.add(issueElastic);
			}
			mapComplaintCoordinates.put(SMRERU83Constants.ISSUES, issues);

			mapComplaintCoordinates.put(SMRERU83Constants.AUDIT_USER, "IAGEN002");
			
			Instant instant = new Date().toInstant();
			mapComplaintCoordinates.put(SMRERU83Constants.AUDIT_DATE, instant.atZone(ZoneId.of("UTC")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSZ")));
			
			mapComplaintCoordinates.put(SMRERU83Constants.REPRESENTATIVE_ORGANIZATION, courtOrderCoordinates.getRepresentativeOrganization().getValue());
			mapComplaintCoordinates.put(SMRERU83Constants.LOCATION_REPRESENTATIVE_ORGANIZATION, getFieldLocations(courtOrderCoordinates.getRepresentativeOrganization()));
			mapComplaintCoordinates.put(SMRERU83Constants.LINKED_COMPLAINT, courtOrderCoordinates.getLinkedComplaintId().getValue());
			mapComplaintCoordinates.put(SMRERU83Constants.LOCATION_LINKED_COMPLAIT, getFieldLocations(courtOrderCoordinates.getLinkedComplaintId()));
			mapComplaintCoordinates.put(SMRERU83Constants.COMPLAINT_REASON_ID, courtOrderCoordinates.getReasonId().getValue());
			
			// Convert the positioning coordinates document to JSON for its insertion to Elasticsearch
			Gson gson = new Gson();
			return gson.toJson(mapComplaintCoordinates);
		}
	    
	    private Map<String, Object> getFieldLocations(CU83PositioningCoordinates field) {
			// If a field does not exist, do not insert an empty location object
			if (field == null) {
				return Collections.emptyMap();
			}

			List<String> documents = new ArrayList<>();
			List<List<Integer>> pages = new ArrayList<>();
			List<CU83Location> fieldLocations = field.getLocation();
			
			fieldLocations.stream().forEach(location -> {
				documents.add(location.getDocument());
				pages.add(location.getPages());
			});
			
			Map<String, Object> locations = new HashMap<>();
			locations.put(SMRERU83Constants.DOCS, documents);
			locations.put(SMRERU83Constants.PAGES, pages);
			
			return locations;
		}
	    
	    private void tl(String mensa) {
			log.info(mensa);
		}
	   
}
