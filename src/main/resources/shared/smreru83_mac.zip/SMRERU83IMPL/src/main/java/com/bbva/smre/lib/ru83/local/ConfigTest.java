package com.bbva.smre.lib.ru83.local;


import com.bbva.elara.configuration.manager.application.ApplicationConfigurationService;
import com.bbva.elara.utility.api.connector.APIConnector;
import com.bbva.smre.lib.ru83.helpers.ElasticHelper;
import com.bbva.smre.lib.ru83.helpers.Validations;

import com.bbva.smre.lib.ru83.interfaces.IElasticHelper;
import com.bbva.smre.lib.ru83.utils.Utils;
import com.bbva.smre.lib.ru83.values.SMRERU83Constants;

public class ConfigTest {
	
	private ConfigTest() {}
	
	public static IElasticHelper initElas(ApplicationConfigurationService acs,APIConnector                    internalApiConnector,Validations val) {
		if("LOCAL".equals(Utils.getStrProp(acs, SMRERU83Constants.CAPX_RUN_MODE,SMRERU83Constants.CAPX_RUN_MODE_DV))) {
			return new com.bbva.smre.lib.ru83.local.ElasticHelper(acs, internalApiConnector, val);
		}
		return new ElasticHelper(acs, internalApiConnector, val);
		
	}
	

}
