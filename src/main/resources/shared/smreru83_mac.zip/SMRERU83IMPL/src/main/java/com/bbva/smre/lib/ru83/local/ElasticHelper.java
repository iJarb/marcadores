package com.bbva.smre.lib.ru83.local;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;

import com.bbva.elara.utility.api.connector.APIConnector;
import com.bbva.elara.configuration.manager.application.ApplicationConfigurationService;

import com.bbva.smre.dto.cu83old.coordinates.C83CourtOrderPositioningCoordinates;
import com.bbva.smre.dto.cu83.CU83CourtOrderDTO;
import com.bbva.smre.lib.ru83.helpers.ElasticResponse;

import com.bbva.smre.lib.ru83.helpers.Validations;
import com.bbva.smre.lib.ru83.interfaces.IElasticHelper;
import com.bbva.smre.lib.ru83.mappers.ElasticObjectMapperFactory;
import com.bbva.smre.lib.ru83.values.SMRERU83Constants;
import com.bbva.smre.lib.ru83.values.SMRERU83Errors;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.gson.Gson;

import org.slf4j.LoggerFactory;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

public class ElasticHelper implements IElasticHelper{
	
	private static final String QUERY_PARAMS = "QUERY_PARAMS";
	private static final String URL_CONTEXT = "URL_CONTEXT";
	
	private static final String elasticBaseUrl = "http://localhost:9200";
	private static final String indexName = "i_smre_es_posit_coord_court_order_ai";
	                                         
	
	private static final org.slf4j.Logger log = LoggerFactory.getLogger(ElasticHelper.class);
	
	
	private final RestTemplate restTemplate;
	
	ApplicationConfigurationService acs;
	APIConnector                    internalApiConnector;
	Validations val;
	MapperElastic me;
	private final ObjectMapper objectMapper;
	
	 String elasticUrl;
	 String elasticIndex;
	 String elasticDocPath;
	
	public ElasticHelper(ApplicationConfigurationService acs,APIConnector                    internalApiConnector,Validations val) {
		this.acs=acs;
		this.internalApiConnector=internalApiConnector;
		this.val=val;
		this.me = new MapperElastic(acs);
		this.objectMapper = ElasticObjectMapperFactory.createObjectMapper();
		
		elasticUrl     = this.acs.getProperty(SMRERU83Constants.ELASTIC_URL);
        elasticIndex   = this.acs.getProperty(SMRERU83Constants.ELASTIC_INDEX);
        elasticDocPath = this.acs.getProperty(SMRERU83Constants.ELASTIC_DOC_PATH);
        
        this.restTemplate = new RestTemplate();
        
	}
	
	
	// -APC_ELK_DOMAIN_TICKETING/{URL_CONTEXT}?{QUERY_PARAMS}-
	
	public String getDocFromElasticOld(String idMail) {
		
        tl(SMRERU83Constants.SEM_LOG+"getDocFromElastic - idMail: "+ idMail);

        if(!checkElasticConfig()) {
			return SMRERU83Errors.ERROR_ELASTIC;
		}

        String fullUrl = elasticUrl + "/" + elasticIndex + elasticDocPath + idMail;
        tl(SMRERU83Constants.SEM_LOG+"Elastic GET URL: " + fullUrl);

        HttpHeaders headers = new HttpHeaders();
        headers.set(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
        headers.add(HttpHeaders.CONTENT_TYPE, "application/json;charset=UTF-8");
        HttpEntity<String> entity = new HttpEntity<>(headers);

        Map<String, String> params = new HashMap<>();
		params.put(URL_CONTEXT, String.format("%s/%s", elasticIndex, "_search"));
		params.put(QUERY_PARAMS, String.format("_id=%s", idMail));
        
		ResponseEntity<HashMap<String,Object>> response = null;
		
		
		try {
			
			ResponseEntity<ElasticResponse> responseEntity = this.internalApiConnector.postForEntity(
		            SMRERU83Constants.ELASTIC_API,
		            entity,
		            ElasticResponse.class,
		            params
		    );
		    
		 
		    response = (ResponseEntity<HashMap<String, Object>>) (ResponseEntity<?>) responseEntity;

		
		
		 } catch (RestClientException e) {
			 val.addAdviceFunctional(SMRERU83Errors.ERROR_ELASTIC);
			 tl("Error en la inserción de los registros a Elasticsearch: "+ e);
		}		
		
		
		
        if (response==null || response.getBody() == null) {
        	tl(SMRERU83Constants.SEM_LOG+"Respuesta nula de Elastic para idMail: "+ idMail);
            return null;
        }
        tl(SMRERU83Constants.SEM_LOG + "Elastic response status: "+ response.getStatusCodeValue());
        
        return Objects.toString(response.getBody());
    }

	

	
	public String genDocToElastic(C83CourtOrderPositioningCoordinates courtOrderCoordinates) {
		
		tl(SMRERU83Constants.SEM_LOG+"genDocToElastic - courtOrderCoordinates: "+ courtOrderCoordinates);
		
		if (!checkElasticConfig()) {
			return SMRERU83Errors.ERROR_ELASTIC;
		}
		String fullUrl = elasticUrl + "/" + elasticIndex + elasticDocPath + courtOrderCoordinates.getIdMail();
		tl(SMRERU83Constants.SEM_LOG + "Elastic GET URL: "+ fullUrl);

		HttpHeaders headers = new HttpHeaders();
		headers.set(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
		
		String jsonQuery = me.buildJsonElastic(courtOrderCoordinates);
		
		StringBuilder body = new StringBuilder(2000 * 10); 
		String lineSep = System.lineSeparator(); 
		
		String jsonComplaintCoordinates = me.buildJsonElastic(courtOrderCoordinates);
		
		String jsonIndexAction = indexActionBulk(courtOrderCoordinates.getIdMail());
		
        tl("Consulta JSON para Elasticsearch: "+ jsonQuery);
        body.append(jsonIndexAction).append(lineSep).append(jsonComplaintCoordinates).append(lineSep);
	
		HttpEntity<String> request = new HttpEntity<>(body.toString(), headers);

	
		
		 Map<String, String> params = new HashMap<>();
			params.put(URL_CONTEXT, String.format("%s/%s", elasticIndex, "_search"));
			params.put(QUERY_PARAMS, String.format("_id=%s", courtOrderCoordinates.getIdMail()));
	
			//-HashMap<String, Object> response = null-
			
			ResponseEntity<HashMap<String,Object>> response = null;
			
		try {
			response = this.internalApiConnector.exchange(
		            SMRERU83Constants.ELASTIC_API,
		            HttpMethod.POST,
		            new HttpEntity<>(request), // Envuelve tu objeto 'request' aquí
		            new ParameterizedTypeReference<HashMap<String, Object>>() {},
		            params
		    );
		
		
		 } catch (RestClientException e) {
			 val.addAdviceFunctional(SMRERU83Errors.ERROR_ELASTIC);
			 tl("Error en la inserción de los registros a Elasticsearch: "+ e);
		}		
		if (response ==null || response.getBody() == null) {
			tl(SMRERU83Constants.SEM_LOG + "Respuesta nula de Elastic para courtOrder: "+ courtOrderCoordinates);
			return null;
		}
		tl(SMRERU83Constants.SEM_LOG + "Elastic response status: "+ response.getStatusCodeValue());

		return Objects.toString(response.getBody());
	}
	
	private String indexActionBulk(String id) {
        // Specify the Elasticsearch document ID
        Map<String, Object> docId = new HashMap<>();
        docId.put(SMRERU83Constants.ID, id);

        // Create an index action
        Map<String, Object> index = new HashMap<>();
        index.put(SMRERU83Constants.INDEX, docId);

        // Convert the index action object to JSON in order to specify the operation to be performed in Elasticsearch
        Gson gson = new Gson();
        return gson.toJson(index);
    }
	
	private boolean checkElasticConfig() {
		if (elasticUrl == null || elasticIndex == null || elasticDocPath == null) {
			tl(SMRERU83Constants.SEM_LOG+
					"Configuración de Elastic incompleta: url="+elasticUrl+", index="+elasticIndex+", docPath="+ elasticDocPath);
			return false;
		}
		return true;
	}
	
	public List<CU83CourtOrderDTO> buscarPorIdExpedienteJudicial(String idExpediente) {
        String url = String.format("%s/%s/_search", elasticBaseUrl, indexName);
        List<CU83CourtOrderDTO> resultados = new ArrayList<>();

        try {
            // Construimos dinámicamente el Query DSL usando Jackson para evitar strings planos propensos a errores
            // Estructura generada: {"query": {"term": {"judicial_file_id": "VALOR"}}}
            ObjectNode queryPayload = objectMapper.createObjectNode();
            ObjectNode queryNode = objectMapper.createObjectNode();
            ObjectNode termNode = objectMapper.createObjectNode();
            
            termNode.put("judicial_file_id", idExpediente);
            queryNode.set("term", termNode);
            queryPayload.set("query", queryNode);

            String requestBody = objectMapper.writeValueAsString(queryPayload);

            // Configuramos las cabeceras HTTP necesarias
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<String> entity = new HttpEntity<>(requestBody, headers);

            // Consumimos la API mediante POST
            ResponseEntity<String> response = restTemplate.exchange(
            		url, HttpMethod.POST, entity, String.class);
            
            

            if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
                JsonNode rootNode = objectMapper.readTree(response.getBody());
                
                // Navegamos por la estructura estándar de respuesta: hits -> hits -> lista de documentos
                if (rootNode.has("hits") && rootNode.get("hits").has("hits")) {
                    JsonNode hitsArray = rootNode.get("hits").get("hits");
                    
                    for (JsonNode hit : hitsArray) {
                        if (hit.has("_source")) {
                            CU83CourtOrderDTO dto = objectMapper.treeToValue(hit.get("_source"), CU83CourtOrderDTO.class);
                            if (dto != null && hit.has("_id")) {
                                dto.setId(hit.get("_id").asText());
                            }
                            resultados.add(dto);
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("Error en la ejecución de la búsqueda: " + e.getMessage());
        }
        return resultados;
    }
	
	public String insertarDocumento(CU83CourtOrderDTO dto) {
        // Endpoint REST nativo para inserción: POST /nombre_indice/_doc
       //String url = String.format("%s/%s/_doc", elasticBaseUrl, indexName);

        try {
            // Convertimos el DTO a JSON String usando nuestro ObjectMapper configurado.
            // Gracias a las anotaciones @JsonProperty, @JsonInclude(NON_NULL) y la exclusión de timestamps,
            // el JSON resultante tendrá formato snake_case, omitirá nulos y formateará la fecha como ISO.
            String jsonPayload = objectMapper.writeValueAsString(dto);

            // Configuramos las cabeceras HTTP estrictas para JSON
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<String> entity = new HttpEntity<>(jsonPayload, headers);

            
            String routingValue = dto.getMailboxDesc() + dto.getMailUniqId(); 
            
            String url = UriComponentsBuilder.fromHttpUrl(elasticBaseUrl)
                    .pathSegment(indexName, "_doc")
                    .queryParam("routing", routingValue)
                    .build()
                    .toUriString();
            
            
            // Ejecutamos la petición HTTP POST
            ResponseEntity<String> response = restTemplate.postForEntity(url, entity, String.class);

            if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
                JsonNode rootNode = objectMapper.readTree(response.getBody());
                
                // La API de indexación de Elasticsearch devuelve un JSON con el campo "_id" generado
                if (rootNode.has("_id")) {
                    return rootNode.get("_id").asText();
                }
            }
        } catch (Exception e) { //NOSONAR
            tl("Error al insertar el documento en Elasticsearch: " + e.getMessage());
        }
        return null;
    }
	
	private void tl(String mensa) {
		log.info(mensa);
	}


	@Override
	public List<CU83CourtOrderDTO> getDocFromElastic(String idMail) {
		// TODO Auto-generated method stub
		return null;
	}


}
