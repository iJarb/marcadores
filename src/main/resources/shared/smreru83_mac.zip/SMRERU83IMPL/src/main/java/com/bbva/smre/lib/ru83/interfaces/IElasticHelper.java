package com.bbva.smre.lib.ru83.interfaces;

import java.util.List;

import com.bbva.smre.dto.cu83.CU83CourtOrderDTO;

public interface IElasticHelper {

	List<CU83CourtOrderDTO> getDocFromElastic(String idMail);

	String insertarDocumento(CU83CourtOrderDTO dto);

}