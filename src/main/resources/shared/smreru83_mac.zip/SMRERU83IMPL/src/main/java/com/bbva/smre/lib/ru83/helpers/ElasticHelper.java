package com.bbva.smre.lib.ru83.helpers;

import java.util.ArrayList;
import java.util.List;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import com.bbva.elara.utility.api.connector.APIConnector;
import com.bbva.elara.configuration.manager.application.ApplicationConfigurationService;

import com.bbva.smre.dto.cu83.CU83CourtOrderDTO;
import com.bbva.smre.lib.ru83.interfaces.IElasticHelper;

import com.bbva.smre.lib.ru83.mappers.ElasticObjectMapperFactory;
import com.bbva.smre.lib.ru83.values.SMRERU83Constants;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.slf4j.LoggerFactory;

public class ElasticHelper implements IElasticHelper{
	
	private static final String QUERY_PARAMS = "QUERY_PARAMS";
	private static final String URL_CONTEXT = "URL_CONTEXT";
	
	
	ApplicationConfigurationService acs;
	APIConnector                    internalApiConnector;
	Validations val;
	
	private final ObjectMapper objectMapper;
	
	 String elasticUrl;
	 String elasticIndex;
	 String elasticDocPath;
	 
	 private static final org.slf4j.Logger log = LoggerFactory.getLogger(ElasticHelper.class);
	
	public ElasticHelper(ApplicationConfigurationService acs,APIConnector                    internalApiConnector,Validations val) {
		this.acs=acs;
		this.internalApiConnector=internalApiConnector;
		this.val=val;
	
		this.objectMapper = ElasticObjectMapperFactory.createObjectMapper();
		
		
		
		elasticUrl     = this.acs.getProperty(SMRERU83Constants.ELASTIC_URL);
        elasticIndex   = this.acs.getProperty(SMRERU83Constants.ELASTIC_INDEX);
        elasticDocPath = this.acs.getProperty(SMRERU83Constants.ELASTIC_DOC_PATH);
        
	}
	
	
		
	
	
	public List<CU83CourtOrderDTO> getDocFromElastic(String idExpediente) {
        //_String url = String.format("%s/%s/_search", elasticBaseUrl, indexName)_
        List<CU83CourtOrderDTO> resultados = new ArrayList<>();

        try {
            // Construimos dinámicamente el Query DSL usando Jackson para evitar strings planos propensos a errores
            // Estructura generada: {"query": {"term": {"judicial_file_id": "VALOR"}}}
            ObjectNode queryPayload = objectMapper.createObjectNode();
            ObjectNode queryNode = objectMapper.createObjectNode();
            ObjectNode termNode = objectMapper.createObjectNode();
            
            termNode.put("judicial_file_id", idExpediente);
            queryNode.set("term", termNode);
            queryPayload.set("query", queryNode);

            String requestBody = objectMapper.writeValueAsString(queryPayload);

            // Configuramos las cabeceras HTTP necesarias
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<String> entity = new HttpEntity<>(requestBody, headers);

            // Consumimos la API mediante POST
            //_ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.POST, entity, String.class)_
            
            ResponseEntity<String> response =response = this.internalApiConnector.exchange(
		            SMRERU83Constants.ELASTIC_API,
		            HttpMethod.POST,
		            entity, // Envuelve tu objeto 'request' aquí
		            String.class);
            

            if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
                JsonNode rootNode = objectMapper.readTree(response.getBody());
                
                // Navegamos por la estructura estándar de respuesta: hits -> hits -> lista de documentos
                if (rootNode.has("hits") && rootNode.get("hits").has("hits")) {
                    JsonNode hitsArray = rootNode.get("hits").get("hits");
                    
                    for (JsonNode hit : hitsArray) {
                        if (hit.has("_source")) {
                            CU83CourtOrderDTO dto = objectMapper.treeToValue(hit.get("_source"), CU83CourtOrderDTO.class);
                            if (dto != null && hit.has("_id")) {
                                dto.setId(hit.get("_id").asText());
                            }
                            resultados.add(dto);
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("Error en la ejecución de la búsqueda: " + e.getMessage());
        }
        return resultados;
    }
	
	public String insertarDocumento(CU83CourtOrderDTO dto) {
        // Endpoint REST nativo para inserción: POST /nombre_indice/_doc
       //_ String url = String.format("%s/%s/_doc", elasticBaseUrl, indexName);_

        try {
            // Convertimos el DTO a JSON String usando nuestro ObjectMapper configurado.
            // Gracias a las anotaciones @JsonProperty, @JsonInclude(NON_NULL) y la exclusión de timestamps,
            // el JSON resultante tendrá formato snake_case, omitirá nulos y formateará la fecha como ISO.
            String jsonPayload = objectMapper.writeValueAsString(dto);

            // Configuramos las cabeceras HTTP estrictas para JSON
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<String> entity = new HttpEntity<>(jsonPayload, headers);

            // Ejecutamos la petición HTTP POST
            //=ResponseEntity<String> response = restTemplate.postForEntity(url, entity, String.class)-
            ResponseEntity<String> response =response = this.internalApiConnector.postForEntity(
		            SMRERU83Constants.ELASTIC_API,entity, String.class);

            if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
                JsonNode rootNode = objectMapper.readTree(response.getBody());
                
                // La API de indexación de Elasticsearch devuelve un JSON con el campo "_id" generado
                if (rootNode.has("_id")) {
                    return rootNode.get("_id").asText();
                }
            }
        } catch (Exception e) {
            System.err.println("Error al insertar el documento en Elasticsearch: " + e.getMessage());
        }
        return null;
    }
	
	private void tl(String mensa) {
		log.info(mensa);
	}


}
