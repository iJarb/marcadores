package com.bbva.smre.lib.ru83.utils;

import com.bbva.elara.configuration.manager.application.ApplicationConfigurationService;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class Utils {
	
	private Utils() {}
	
	public static JsonObject parseJson(String json) {
        return new JsonParser().parse(json).getAsJsonObject();
    }

    public static String getTextValue(JsonObject obj, String fieldName) {
        if (obj == null || !obj.has(fieldName) || obj.get(fieldName).isJsonNull()) {
            return null;
        }
        return obj.get(fieldName).getAsString();
    }

    public static JsonObject getObject(JsonObject obj, String fieldName) {
        if (obj == null || !obj.has(fieldName) || obj.get(fieldName).isJsonNull() || !obj.get(fieldName).isJsonObject()) {
            return null;
        }
        return obj.getAsJsonObject(fieldName);
    }

    public static JsonArray getArray(JsonObject obj, String fieldName) {
        if (obj == null || !obj.has(fieldName) || obj.get(fieldName).isJsonNull() || !obj.get(fieldName).isJsonArray()) {
            return null;
        }
        return obj.getAsJsonArray(fieldName);
    }

    public static int getIntValue(JsonObject obj, String fieldName, int defaultValue) {
        if (obj == null || !obj.has(fieldName) || obj.get(fieldName).isJsonNull()) {
            return defaultValue;
        }
        return obj.get(fieldName).getAsInt();
    }

    public static Long getLongValue(JsonObject obj, String fieldName) {
        if (obj == null || !obj.has(fieldName) || obj.get(fieldName).isJsonNull()) {
            return null;
        }
        return obj.get(fieldName).getAsLong();
    }
    
    public static String getStrProp(ApplicationConfigurationService acs,String name,String defaultValue) {
		
		if(acs==null || name==null) {
			return defaultValue;
		}
		
		String value = acs.getProperty(name);
		if(value!=null) {
		  return value;
		}
		return defaultValue;
		
	}
    	
	

}
