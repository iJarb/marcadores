package com.bbva.smre.lib.ru83.helpers;


import com.bbva.elara.configuration.manager.application.ApplicationConfigurationService;
import com.bbva.elara.utility.api.connector.APIConnector;
import com.bbva.smre.lib.ru83.interfaces.IElasticHelper;

public class ConfigBbva {

	private ConfigBbva() {
		/* This utility class should not be instantiated */
	}

	public static IElasticHelper initElas(
			ApplicationConfigurationService acs,
			APIConnector                    internalApiConnector,
			Validations val) {

		return new ElasticHelper(acs, internalApiConnector, val);

	}

	
}
