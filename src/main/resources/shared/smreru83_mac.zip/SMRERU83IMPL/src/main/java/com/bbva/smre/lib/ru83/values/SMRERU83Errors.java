package com.bbva.smre.lib.ru83.values;

public class SMRERU83Errors {
	
	private SMRERU83Errors() {

	}
	
	//ENTRADA CON DATOS INCORRECTOS
	public static final String LOS_DATOS_INFORMADOS_NO_SON_CORRECTOS = "SMRE01267004";
	//ERROR TECNICO
	public static final String ERROR_TECNICO = "SMRE01267007";
	
	
	public static final String ERROR_ELASTIC  = "SMRE99999999";

}
