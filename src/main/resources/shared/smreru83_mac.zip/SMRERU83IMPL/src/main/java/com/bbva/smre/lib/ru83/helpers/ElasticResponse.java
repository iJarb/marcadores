package com.bbva.smre.lib.ru83.helpers;

public class ElasticResponse extends java.util.HashMap<String, Object> {

}
