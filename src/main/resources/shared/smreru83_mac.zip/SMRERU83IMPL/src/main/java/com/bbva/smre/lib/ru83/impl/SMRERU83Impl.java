package com.bbva.smre.lib.ru83.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.bbva.smre.dto.cu83.CU83CourtOrderDTO;
import com.bbva.smre.lib.ru83.interfaces.IElasticHelper;
import com.bbva.smre.lib.ru83.helpers.Validations;
import com.bbva.smre.lib.ru83.values.SMRERU83Constants;
import com.bbva.smre.lib.ru83.values.SMRERU83Errors;
import com.bbva.smre.lib.ru83.helpers.ConfigBbva;

import org.slf4j.LoggerFactory;

public class SMRERU83Impl extends SMRERU83Abstract {

	
	private static final org.slf4j.Logger log = LoggerFactory.getLogger(SMRERU83Impl.class);
	
	@Override
	public List<com.bbva.smre.dto.cu83.CU83CourtOrderDTO> executeGetCourtOrder(String id) {
		
		Validations val = new Validations(new ArrayList<>());
		
        val.validateParmIn(id);
        
        if(!val.getErrors().isEmpty()) {
			tl(SMRERU83Constants.SEM_LOG + " Validation errors executeGetCourtOrder: " + val.getErrors());
			return Collections.emptyList();
		}
		
		IElasticHelper elh;
		
		elh = ConfigBbva.initElas(applicationConfigurationService, internalApiConnector, val);
		
		tl("executeGetCourtOrder: id="+ id);
		
        List<com.bbva.smre.dto.cu83.CU83CourtOrderDTO> elasticResponse =  elh.getDocFromElastic(id);
		
		tl(String.format("%s genDocToElastic=%s",SMRERU83Constants.SEM_LOG,elasticResponse));						
		
		addErrors(val);
		
		if(SMRERU83Errors.ERROR_ELASTIC.equals(elasticResponse)) {
			tl(SMRERU83Constants.SEM_LOG+"Error al obtener documento de Elastic para Id: "+ id);
			return Collections.emptyList();
		}
		return elasticResponse;
		
		
		
	}

	@Override
	public void executeInsertCourtOrderCoordinates(CU83CourtOrderDTO courtOrderCoordinates) {
		
		tl("executeInsertCourtOrderCoordinates: courtOrderDTO="+ courtOrderCoordinates);
		
        Validations val = new Validations(new ArrayList<>());
		
        val.validateParmIn(courtOrderCoordinates);
        
        if(!val.getErrors().isEmpty()) {
			tl(SMRERU83Constants.SEM_LOG + " Validation errors executeInsertCourtOrderCoordinates: " + val.getErrors());
			return;
		}
        
		IElasticHelper elh;
		
		elh = ConfigBbva.initElas(applicationConfigurationService, internalApiConnector, val);
		
		tl("executeInsertCourtOrderCoordinates: id="+ courtOrderCoordinates);		     
		
		String elasticResponse =  elh.insertarDocumento(courtOrderCoordinates);
		
		tl(String.format("%s executeInsertCourtOrderCoordinates = %s",SMRERU83Constants.SEM_LOG,elasticResponse));
		
		
		
	}
	
private void addErrors(Validations val) {
		
		List<String> errors = val.getErrors();
		
		if(errors.isEmpty()) {
			return;
		}
				
        for(String error:errors) {
          if(error.length()>3) {
            this.addAdvice(error);
          }
        }			
	}

private void tl(String mensa) {
	log.info(mensa);
}
}
